---
name: discovery-prd-foundation
description: "Stage 3.1 (non-agentic path) of Discovery to Prototype Engine. Creates a concise PRD foundation for a selected opportunity including problem statement, solution concept, user flows, and success metrics. Use when user says 'create a PRD', 'write product requirements', 'run discovery stage 3', or selects a non-agentic opportunity to develop. Outputs structured PRD for prototype generation."
---

# Discovery PRD Foundation (Stage 3.1 — Non-Agentic Path)

Creates a structured PRD for non-agentic solutions — traditional features, UI improvements, and workflow enhancements. This is the non-agentic branch of Stage 3. For agentic solutions, see `discovery-agent-prd`.

## Prerequisites

Requires a selected opportunity and committed solution concept from Stage 2 (Solution Prioritization), or user-provided:
- Problem description
- Solution concept (flagged as non-agentic)
- Target user segment
- Business impact context

## Workflow

1. **Receive input** — Accept selected opportunity + committed solution concept from Stage 2, or user input
2. **Expand problem** — Develop detailed problem statement with context
3. **Define solution** — High-level concept (not detailed design)
4. **Map user flows** — 3-5 key scenarios the prototype should address
5. **Set success criteria** — Measurable goals and metrics
6. **Document risks** — Dependencies, assumptions, blockers
7. **Output PRD** — Deliver structured document, checkpoint for review

## PRD Structure

### 1. Feature Name
Short, descriptive name (2-5 words)

### 2. Problem Statement
What user problem are we solving? Include:
- Who experiences this problem
- When/where it occurs
- Why it matters (impact)
- Current workarounds (if any)

### 3. Proposed Solution
High-level concept only — avoid detailed design:
- Core idea in 1-2 sentences
- Key capabilities it provides
- What it does NOT include (scope boundaries)

### 4. Target Segments
Specific user groups with qualifying characteristics:
- Primary segment (must-serve)
- Secondary segments (nice-to-serve)
- Explicitly excluded segments

### 5. Use Cases
3-5 key user flows the prototype should demonstrate:

| # | As a... | I want to... | So that... |
|---|---------|--------------|------------|
| 1 | [persona] | [action] | [outcome] |

### 6. Success Metrics
How we know this works:

| Metric | Current State | Target | Measurement Method |
|--------|---------------|--------|-------------------|
| [metric name] | [baseline] | [goal] | [how to measure] |

### 7. Dependencies & Risks
Technical constraints, blockers, assumptions:

| Type | Description | Mitigation |
|------|-------------|------------|
| Dependency | [what we need] | [how to handle] |
| Risk | [what could go wrong] | [how to reduce] |
| Assumption | [what we're assuming] | [how to validate] |

## Output Format

Deliver as a Markdown document following the structure above. See `references/prd-template.md` for full template with examples.

## Writing Guidelines

- **Be concise** — PRD foundation, not full spec
- **Stay high-level** — Avoid pixel-level detail
- **Focus on "what" not "how"** — Leave implementation to prototype
- **Include boundaries** — What's out of scope is as important as what's in

## Checkpoint Behavior

After outputting the PRD:
1. Ask user to review for completeness
2. Confirm scope boundaries are correct
3. Validate use cases cover key scenarios
4. Get approval before proceeding to Stage 4 (Component Library)

Once the user approves the PRD, show this handoff message:

```
Stage 3 complete! PRD approved.

---

**Next step → Stage 4: Build the Component Library**

I'll analyze screenshots of your current product to extract UI components (buttons, forms, cards, navigation, etc.) so the prototype looks and feels like your real product.

You'll need: 5–10 screenshots of your product's existing UI
  - Include your main navigation, key screens, and common UI elements
  - Real product screenshots work best (not mockups)

Type: "Build component library" or "Run Stage 4"
→ Then upload your screenshots when prompted.

No screenshots? Type "Skip to prototype" and I'll use default Tailwind styles instead — the prototype will be functional but won't match your product's visual design.
```

## Presenting Output

After the user approves the PRD at the checkpoint:

1. Write the PRD to the working directory as `stage-3-prd-[feature-name].md` (keep this exact `stage-3-prd` prefix — it's how stage progress is detected)
2. Also save a copy to the user's workspace folder under the same filename
3. Call `present_files` to show the file to the user as a downloadable card. (If `present_files` is not available in this environment, skip it: state the full saved file path and offer to print the file contents instead.)
4. Tell the user: "Here's your PRD — download it to share with your team or re-upload in a future session to resume from Stage 4."

## Chaining

This skill is designed to work both **standalone** and as part of the Discovery to Prototype Engine.

### Standalone use
Run independently when you have a clear opportunity and want to produce a structured PRD. Useful for sprint planning, stakeholder alignment, or prototype briefing.

### As part of the engine
- **Input from**: Stage 2 (Solution Prioritization) — selected opportunity + committed non-agentic solution concept
- **Output to**: Stage 4 (Component Library) and Stage 5 (Prototype Generator)

Both this skill and the agentic path (`discovery-agent-prd`) converge at Stage 4 — both produce a concise PRD that feeds into component extraction and prototype generation.

To continue: "Build component library" or "Run Stage 4"

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (in Cowork this is `AskUserQuestion`), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. A `Type: "..."` handoff becomes a button with that wording, for example "Run Stage 4", next to "Stop here".
- **Fall back to the list.** Without such a tool, or with more than 4 options, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** When this skill runs as part of the full engine (earlier stage files exist in the engine working directory), start each checkpoint with one line: this stage, then `Sense` before the path is set, or `Standard path` / `Agent path` from the agentic flag in `stage-2-selected-opportunity.md`. For example `Stage 4 of 6 · Agent path`, or `Pattern check (optional) · Agent path`. Skip the line when the skill runs standalone.
