---
name: discovery-engine-start
description: The front door of the Discovery to Prototype Engine — run a readiness scan of the current environment (previous run outputs, customer data, connectors, design system, plugin version), show the whole journey map, and route the user to their one next step. Ends with an explicit choice — guided from the beginning, jump to a specific point, resume a previous run, or run a single skill standalone. Use on first contact with the plugin, when returning after a break, when unsure what to do next, or whenever the user says "start the discovery engine", "get started", "where do I start", "what's my next step", "am I ready", "check my setup", or "run the readiness scan".
---

# Discovery Engine — Start

The activation moment. A user who installed the plugin should not need to read the
README to know what to do next: this skill detects what they have, shows them the
whole journey, and hands them one concrete next step. Not every user is confident or
outspoken — never leave them at an open end. Every pause here finishes with a small
set of labeled options.

Three audiences, one skill:

- **A first-time user** — "I installed this, now what?"
- **A returning user** — "where was I?" (detect their previous run and offer to resume)
- **A single-skill user** — someone who only wants one piece (just competitor research,
  just a prototype) and should never be forced through the full 9-stage workflow

## Workflow

### Step 1: Detect (silently)

Check, without asking the user anything yet:

1. **Previous run** — does the engine working directory exist (`/home/claude/discovery-engine/`,
   or `./discovery-engine/` in Claude Code)? If yes, which stage output files are present
   (`product-context.md`, `stage-1-1-*` … `stage-6-*`)? The furthest file tells you where
   they left off. Also check `radar/config.md` — an active radar is worth reporting.
2. **Customer data** — are there CSV files in the working directory or an obvious data
   folder? A cheap look only — don't open or analyze them; that's Stage 1.1's job.
3. **Connectors** — if `search_mcp_registry` is available, check for Google Drive, a
   feedback tool (Intercom, Productboard, Zendesk, BigQuery), Figma, and Slack. **If the
   registry tools are not available in this environment, skip connector detection entirely
   — do not error and do not mention it.**
4. **Design system** — is there a component library or design-system folder nearby
   (`component-library/`, a `manifest.json` with components, `tokens.json`)? Presence
   check only — the real analysis is Stage 4's job.
5. **Plugin version** — read the installed version from
   `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`, then fetch the latest released
   version with
   `curl -s --max-time 3 "https://prod-discovery.github.io/discovery-engine-guide/downloads/version.json"`.
   Compare as semantic versions (1.7.10 is newer than 1.7.2, not older). If the fetch
   fails or times out — offline, proxy, firewall — skip this check entirely and never
   mention it, not even to say the check was skipped or which version is installed:
   the scan must work without internet, and a missing version row is better than a
   scary false warning or an unexplained caveat.
6. **Duplicate plugins** — if the Closing the Loop plugin is also installed (its skills
   appear alongside this plugin's), note it: CTL bundles its own copy of these discovery
   skills and competes for the same trigger phrases. Recommend using one copy — teams
   running Closing the Loop should use CTL's copy and can uninstall this standalone plugin.

### Step 2: Report the readiness status

Show one compact checklist — ✅ / ⚠️ / ❌ per item — in this order: plugin version,
previous run, customer data, connectors (mark "optional" plainly), design system (mark
"optional — Stage 4 can also build one from screenshots or from scratch"), radar.
One line each, plain language, no jargon. Every line NAMES the item. Example lines:

`✅ Previous run — found a run that reached Stage 2 (selected opportunity). You can resume from Stage 3.`
`⚠️ Customer data — no CSV files found nearby. Needed for Stage 1.1; you can also paste data or work from a description.`

The **plugin version** line (omit it entirely when the Step 1 fetch was skipped):

- Up to date → `✅ Plugin version — 1.8.0 (latest)`.
- Outdated → a ⚠️ line naming both versions, followed by the update path that matches
  this install: if the plugin folder sits under a Claude marketplace directory, tell them
  to run `claude plugin update discovery-engine-plugin` and restart; otherwise it came
  from the ZIP — tell them to re-download it from
  https://prod-discovery.github.io/discovery-engine-guide/, replace the plugin folder,
  and restart. If unsure, show both paths, each labeled with who it's for. Never tell a
  ZIP user to run the update command — without marketplace access it does nothing.

### Step 3: Show the journey map (always, ~10 lines)

```
THE ENGINE — from raw customer feedback to a validated prototype

  SENSE         Stages 0–2   Context → customer + competitor insights →
                             Top 5 opportunities → scored choice
  SHAPE         Stages 3–6   PRD → your components → interactive prototype →
                             experiment plan + usability test
  KEEP SENSING  Radar        Scheduled weekly/monthly re-scan of your feedback —
                             pings you when a strong new opportunity appears
```

### Step 4: Offer the choice (always end here)

```
What would you like to do?

A) Start from the beginning — I'll guide you stage by stage. I'll reuse
   everything the scan already found, so you won't be asked twice.
B) Jump to a specific point — tell me what you already have:
   "I have customer data"      → analyze it (Stage 1.1)
   "I have a list of problems" → score them (Stage 2)
   "I have a PRD"              → component library + prototype (Stages 4–5)
   "I have a prototype"        → experiment plan (Stage 6)
   [If a previous run was detected: "Resume my last run" → continue from Stage N]
C) Run just one skill on its own — no workflow, no commitment:
   "Analyze this customer data" · "Research competitors" · "Create a PRD for …" ·
   "Build component library" · "Generate prototype" · "Create test plan" ·
   "Set up the radar" · "Radar demo" (see it on sample data first)

Which would you prefer — A, B, or C?
```

Mark the recommended option based on what Step 1 found: a detected previous run →
recommend resuming (B); nothing at all → recommend A; data files present but no run →
recommend B ("I have customer data"). Add "(Recommended)" after that option's letter.

Route accordingly: A → the `discovery-to-prototype-engine` orchestrator — pass along
everything the scan detected (context files, data files, connectors) so Stage 0 confirms
instead of re-asking; B → the matching stage skill with the detected files as input;
C → the named skill, standalone.

💬 Include this line once, near the end: *you can send us feedback at any moment — just
say "give feedback". A quick 1–5 rating plus an optional comment, completely anonymous.
You don't need to finish anything first.*

## What this skill is NOT

- Not the explainer — `discovery-getting-started` owns "what is this plugin". If the
  user only wants orientation, hand over to it.
- Not the orchestrator — `discovery-to-prototype-engine` owns the full workflow and its
  checkpoints. This skill detects, orients, and routes; then it hands over.
- Not the stage documentation — each stage skill documents its own inputs and outputs.
- Not setup for the radar — that's `discovery-radar` (say "set up the radar").

## Output

The readiness checklist, the journey map, and the user's chosen route — ending with the
next skill invoked or the explicit A/B/C question still open. Never end with "let me
know how to proceed."
