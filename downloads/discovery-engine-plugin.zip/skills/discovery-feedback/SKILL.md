---
name: discovery-feedback
description: Collect a 1-5 star rating and optional comment from the user about their experience with the Discovery to Prototype Engine, then submit it as an anonymous feedback event for the maintainers. Use when the user finishes a workflow, when they ask to "give feedback" / "rate this" / "share feedback", when an experiment plan is completed in Stage 6, or whenever they want to share thoughts about the engine.
---

# Discovery Feedback

Collects anonymous user feedback (1-5 rating + optional comment) about the Discovery to Prototype Engine. The maintainers use this signal to prioritize improvements.

## When to invoke

- After the user completes a full workflow (typically at the end of Stage 6 — Experiment Plan)
- When the user explicitly asks to give feedback, rate the plugin, or share comments
- When the user expresses strong opinions (positive or negative) about the engine and you want to capture them
- At the user's request via `/feedback` or similar phrasing

Do NOT auto-invoke this skill more than once per session. If the user has already submitted feedback in the current session, don't ask again.

## What to do

1. **Ask the user for a rating** on a 1–5 scale:

   > "How would you rate your experience with the Discovery to Prototype Engine? (1 = poor, 5 = excellent)"

2. **Ask for an optional comment**:

   > "Anything else you'd like to share? (optional — press Enter to skip)"

   - Accept any text. Keep it to one prompt — don't pepper them with questions.
   - If the user skips, comment stays empty.

3. **Submit the feedback** by running the tracking script via the Bash tool:

   ```
   "${CLAUDE_PLUGIN_ROOT}/hooks/track-feedback.sh" <rating> "<comment>"
   ```

   - `<rating>` must be a single digit 1-5
   - `<comment>` must be wrapped in double quotes; pass an empty string `""` if the user gave no comment
   - The script trims comments to 500 characters

4. **Confirm to the user** that their feedback was sent. Use the exact output from the script (it prints "Thanks! Your feedback was submitted." on success).

## What NOT to do

- Do NOT include the user's name, email, project name, customer names, or any identifiable info in the comment string — even if they say their name. Substitute generically ("user mentioned a team in their feedback") or omit.
- Do NOT push back on the rating. If they say 1, accept it and move on. Negative feedback is valuable.
- Do NOT ask follow-up questions ("why only 3 stars?") unless they invite the conversation. Respect their time.
- Do NOT submit feedback if the user changed their mind or asked you to cancel.

## Privacy note

This skill sends an anonymous event (rating + comment + anonymized user hash + plugin version) to the maintainers' usage tracking sheet. No conversation context, file contents, prompts, or identifying info is included.

Users who set `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` will see "Telemetry is disabled. Feedback was NOT sent." — let them know if that happens.
