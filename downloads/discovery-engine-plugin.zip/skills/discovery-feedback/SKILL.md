---
name: discovery-feedback
description: Collect a 1-5 star rating and optional comment from the user about their experience with the Discovery to Prototype Engine, then submit it as an anonymous feedback event for the maintainers. Use when the user finishes a workflow, when they ask to "give feedback" / "rate this" / "share feedback", when an experiment plan is completed in Stage 6, or whenever they want to share thoughts about the engine.
---

# Discovery Feedback

Collects anonymous user feedback (1-5 rating + optional comment) about the Discovery to Prototype Engine. The maintainers use this signal to prioritize improvements.

## When to invoke

- After the user completes a full workflow (typically at the end of Stage 6 — Experiment Plan)
- When the user explicitly asks to give feedback, rate the plugin, or share comments
- When the user expresses strong opinions (positive or negative) about the engine and you want to capture them
- At the user's request via `/feedback` or similar phrasing

Do NOT auto-invoke this skill more than once per session. If the user has already submitted feedback in the current session, don't ask again.

## What to do

1. **Ask the user for a rating** on a 1–5 scale:

   > "How would you rate your experience with the Discovery to Prototype Engine? (1 = poor, 5 = excellent)"

2. **Ask for an optional comment**:

   > "Anything else you'd like to share? (optional — press Enter to skip)"

   - Accept any text. Keep it to one prompt — don't pepper them with questions.
   - If the user skips, comment stays empty.

3. **Submit the feedback** by writing a file with the Write tool (a plugin hook picks it up and sends it automatically — do NOT run any tracking script via Bash):

   - Path: `discovery-feedback-<YYYYMMDD-HHMMSS>.md` in the engine working directory (e.g. `/home/claude/discovery-engine/feedback/discovery-feedback-20260707-141503.md`, or the equivalent working directory in this environment). The `discovery-feedback-` filename prefix is required — it's how the hook recognizes the file.
   - Exact content format (two lines, nothing else):

   ```
   Rating: <1-5>
   Comment: <the user's comment, or empty after the colon if none>
   ```

   - Strip any names or identifying info from the comment before writing (see below). Comments are trimmed to 500 characters on send.

4. **Confirm to the user**: "Thanks! Your feedback was submitted anonymously."

## What NOT to do

- Do NOT include the user's name, email, project name, customer names, or any identifiable info in the comment string — even if they say their name. Substitute generically ("user mentioned a team in their feedback") or omit.
- Do NOT push back on the rating. If they say 1, accept it and move on. Negative feedback is valuable.
- Do NOT ask follow-up questions ("why only 3 stars?") unless they invite the conversation. Respect their time.
- Do NOT submit feedback if the user changed their mind or asked you to cancel.

## Privacy note

This skill sends an anonymous event (rating + comment + anonymized user hash + plugin version) to the maintainers' usage tracking sheet. No conversation context, file contents, prompts, or identifying info is included.

For users who set `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1`, the feedback file is still written locally but nothing is sent — if you know telemetry is disabled, tell the user their feedback was saved locally only.
