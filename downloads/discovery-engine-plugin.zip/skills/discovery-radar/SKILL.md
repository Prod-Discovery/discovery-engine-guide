---
name: discovery-radar
description: "Opportunity Radar — scheduled, recurring discovery for the Discovery to Prototype Engine. Instead of waiting for someone to start a discovery cycle, the radar scans the team's customer feedback on a cadence (weekly/monthly), surfaces new opportunity candidates as a short digest, and invites the team to run a full cycle on the promising ones. Use when user says 'set up the radar', 'opportunity radar', 'scheduled discovery', 'run discovery automatically', 'watch our customer feedback', 'weekly opportunities digest', 'radar demo', 'run the radar now', 'radar status', or 'stop the radar'."
---

# Opportunity Radar (scheduled discovery)

Turns the engine's Sense phase from on-demand into recurring. The radar runs a lightweight scan of the team's customer feedback on a schedule, compares against what it found last time, and delivers a short digest: **what's new, what's growing, what's worth a full discovery cycle.**

The full engine stays unchanged — the radar is the doorbell, the engine is the house.

## Modes

Detect which mode the user wants:

| User says | Mode |
|---|---|
| "set up the radar", "scheduled discovery", "watch our feedback" | **Setup** |
| "radar demo", "show me the radar" | **Demo** (no setup, uses bundled sample data) |
| "run the radar now" | **Run** (manual trigger of a configured radar) |
| "radar status" | **Status** |
| "stop the radar", "pause the radar" | **Stop** |

A scheduled task created in Setup also triggers **Run** mode automatically on its cadence.

## Mode: Setup

Ask three questions, one at a time. **At every pause, present the options as a short lettered list (A/B/C…) so the user can answer with a single character** — never make them type a sentence when a letter will do. This applies to every question in every mode of this skill.

1. **Data source** — where does customer feedback live? Detect what's actually available first (same detection as Stage 1.1), then offer only real options, lettered:

   > **A)** [Connected feedback tool, e.g. "Intercom (connected)"] — pulled automatically, no manual work per run *(only list tools that are actually connected; omit this option entirely if none are)*
   > **B)** A folder the team drops exports into — a local folder, or a Google Drive folder if Drive is connected; the radar reads whatever is new there
   > **C)** Not sure yet — show me the demo on sample data first

   If the user picks a folder, offer a default (`discovery-engine/radar/inbox/`) or let them name a path. If no recurring source exists at all, say honestly that a radar needs one, and offer the Demo instead.

2. **Cadence** — lettered again:

   > **A)** Weekly — every Monday at 09:00 (default)
   > **B)** Monthly — the 1st of each month at 09:00
   > **C)** Something else — tell me the day and time

3. **Delivery** — the digest is always saved as a file in `radar/`. On top of that, offer only what can actually reach people. Check for a Slack connector and a mail connector (Gmail, Outlook, Google Workspace), then offer:

   > **A)** Slack — post the digest to a channel you choose
   > **B)** Email — send the digest to an address you choose
   > **C)** Both
   > **D)** Just the file

   Label unavailable options honestly instead of hiding them, e.g. "B) Email — needs a Gmail or Outlook connector, not connected right now." Never offer a Google Drive copy as delivery — a file dropped in a Drive folder is a file nobody opens. Delivery means reaching people where they already look: their Slack or their inbox.

Then:

4. Write the config to `/home/claude/discovery-engine/radar/config.md` (create dirs; use the equivalent engine working directory in this environment):

```markdown
# Opportunity Radar Config
**Source**: [connector name | folder path]
**Cadence**: [weekly Monday 09:00 | monthly 1st 09:00]
**Delivery**: [file | file + Slack #channel | file + email address | file + Slack #channel + email address]
**Created**: [date]
**Product context**: [one line from team profile / product-context.md if present]
```

5. **Create the schedule.** In the Claude desktop app, create a scheduled task (Routine) with the matching cron (weekly `0 9 * * 1`, monthly `0 9 1 * *`) whose prompt is fully self-contained, e.g.:
   > "Run the Opportunity Radar for the Discovery to Prototype Engine plugin: invoke the discovery-radar skill in Run mode. Config is at /home/claude/discovery-engine/radar/config.md. If the config is missing, say the radar isn't set up and stop."
   - If scheduled tasks aren't available in this environment, say so honestly and offer the manual fallback: the user runs "run the radar now" on their own rhythm — everything else works the same.
   - Tell the user the schedule runs when the Claude app is open, and catches up on next launch otherwise.

6. Confirm with a summary and offer to run the first scan immediately.

## Mode: Run

This is what executes on each scheduled (or manual) trigger.

1. **Load state**: read `radar/config.md` and `radar/last-digest.md` (if it exists — first run has no baseline).
2. **Gather new data**: pull from the configured source. Only look at data newer than the last run when the source allows filtering by date; otherwise take the current export and rely on the diff step.
3. **Scan** — a lightweight version of Stage 1.1, tuned for speed over depth:
   - Identify up to **5 opportunity candidates**: recurring pain points, rising complaint categories, repeated feature requests.
   - For each: one-line pattern, evidence count (how many mentions), severity estimate (1–10, same calibration as Stage 1.1), affected segment if visible.
   - No checkpoint questions during a scheduled run — the digest IS the output. Never block waiting for input.
4. **Diff against the last digest**: label each candidate **NEW** (not in last digest), **GROWING** (was there, more evidence now), or **KNOWN** (unchanged). Drop candidates that faded.
5. **Write the digest** to `radar/last-digest.md` AND a dated copy `radar/digest-YYYY-MM-DD.md`, using the format in `references/example-digest.md`. Keep it under one page — it's a nudge, not a report.
6. **Deliver** per config: the file always; then post to the configured Slack channel and/or send to the configured email address via the available connectors. If a configured connector is unavailable during a scheduled run, note it in one line at the top of the digest file and continue — never fail the run over delivery.
7. End the digest with the handoff: the exact phrase to start a full cycle on a candidate, e.g. *"Run the full discovery workflow starting from: [candidate #1]"*.
8. Telemetry: runs invoked via the Skill tool are tracked automatically by a plugin hook — never run any tracking command yourself.

## Mode: Demo

For showing the radar without any setup — uses the bundled fictional dataset.

1. Say this is a demo on fictional data (product: "Fikonomi", invoicing for small cafés).
2. Run the **Run** flow using `sample-data/feedback-sample.csv` as the source, with no previous digest (everything will be NEW).
3. Show the digest inline, plus where a real radar would deliver it and what the schedule would look like.
4. Offer: "Want to set up a real radar on your own data? Say 'set up the radar'."

## Mode: Status / Stop

- **Status**: read `radar/config.md`, report source, cadence, delivery, date of last digest. If no config: "no radar set up".
- **Stop**: delete or disable the scheduled task if one exists, and mark the config `**Status**: paused`. Keep the digests — history stays useful.

## Principles

- **Never fabricate signal.** If a scan finds nothing meaningful, the digest says exactly that ("quiet period — nothing new above the noise floor"). A trustworthy quiet digest is the feature; a padded one kills the radar's credibility in a month.
- **Digest, not analysis.** Depth belongs to the full engine. The radar's entire job is: is there anything here worth a real cycle?
- **Respect the team profile** (`team-profile.md`) if present, for market/language context.
- Same privacy rules as the whole engine: anonymous telemetry only, opt-out via `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1`.

## Chaining

- **Output to**: the full engine — each digest candidate is a ready-made starting point for Stage 0/1.
- The radar never starts a full cycle on its own. It surfaces; humans decide.
