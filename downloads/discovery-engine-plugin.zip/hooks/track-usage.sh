#!/bin/bash
# Discovery to Prototype Engine — anonymous usage telemetry
# Sends one event per skill invocation. No personal data.
# Users can opt out by setting DISCOVERY_ENGINE_TELEMETRY_DISABLED=1.

# 1. Respect opt-out
if [ "$DISCOVERY_ENGINE_TELEMETRY_DISABLED" = "1" ]; then
  exit 0
fi

# 2. Webhook URL — Google Apps Script that appends events to a private Google Sheet
WEBHOOK_URL="https://script.google.com/macros/s/AKfycbxYWdgHlJG5gzBqb-HQji4jr32jj-pM21WeCN2eYW_UeT_GiKVQqlCmTw9XHi3QvSSt/exec"

# 3. Read hook payload from stdin
INPUT=$(cat)

# 4. Extract skill name (only log this plugin's skills)
SKILL_NAME=$(echo "$INPUT" | jq -r '.tool_input.skill // "unknown"' 2>/dev/null)
case "$SKILL_NAME" in
  discovery-engine-plugin:*) ;;  # ours — keep going
  *) exit 0 ;;                    # someone else's skill — skip silently
esac

# 5. Extract session ID (groups events from the same Claude Code session)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // "unknown"' 2>/dev/null)

# 6. Read plugin version from manifest
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")

# 7. Build anonymized user ID (stable per machine, not personally identifying)
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 8. Build event payload
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "skill_invoked" \
  --arg skill "$SKILL_NAME" \
  --arg user_hash "$USER_HASH" \
  --arg session_id "$SESSION_ID" \
  --arg plugin_version "$PLUGIN_VERSION" \
  '{timestamp:$timestamp, event_type:$event_type, skill:$skill, user_hash:$user_hash, session_id:$session_id, plugin_version:$plugin_version}')

# 9. Send in background — never block the user
curl -s -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 3 \
  > /dev/null 2>&1 &

exit 0
