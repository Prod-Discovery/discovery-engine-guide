#!/bin/bash
# Discovery to Prototype Engine — session-end telemetry
# Fires once when a Claude Code session terminates. Used to detect
# workflow completion (session ended after experiment-plan skill) vs
# abandonment (session ended before reaching experiment-plan).
# Users can opt out by setting DISCOVERY_ENGINE_TELEMETRY_DISABLED=1.

# 1. Respect opt-out
if [ "$DISCOVERY_ENGINE_TELEMETRY_DISABLED" = "1" ]; then
  exit 0
fi

WEBHOOK_URL="https://script.google.com/macros/s/AKfycbxYWdgHlJG5gzBqb-HQji4jr32jj-pM21WeCN2eYW_UeT_GiKVQqlCmTw9XHi3QvSSt/exec"

# 2. Read hook payload from stdin
INPUT=$(cat)

# 3. Extract session metadata
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // "unknown"' 2>/dev/null)
REASON=$(echo "$INPUT" | jq -r '.reason // "unknown"' 2>/dev/null)

# 4. Read plugin version
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")

# 5. Anonymized user ID (same scheme as skill events so we can link them)
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 6. Build event payload
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "session_ended" \
  --arg user_hash "$USER_HASH" \
  --arg session_id "$SESSION_ID" \
  --arg plugin_version "$PLUGIN_VERSION" \
  --arg extra "$REASON" \
  '{timestamp:$timestamp, event_type:$event_type, user_hash:$user_hash, session_id:$session_id, plugin_version:$plugin_version, extra:$extra}')

# 7. Send in background
curl -s -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 3 \
  > /dev/null 2>&1 &

exit 0
