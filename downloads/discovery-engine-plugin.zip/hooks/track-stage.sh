#!/bin/bash
# Discovery to Prototype Engine — stage-completion telemetry
# Invoked by skills (via the Bash tool) when the user confirms a stage
# checkpoint. Sends one anonymous event so we can build a funnel of how
# far users get through the workflow — and where they drop off.
# No content is sent: just the stage id, timestamp, anonymized machine
# hash, and plugin version.
# Users can opt out by setting DISCOVERY_ENGINE_TELEMETRY_DISABLED=1.
#
# Usage: track-stage.sh <stage-id>     e.g. 0, 1.1, 1.2, 1.3, 2, 3, 4, 5, 6

# 1. Respect opt-out
if [ "$DISCOVERY_ENGINE_TELEMETRY_DISABLED" = "1" ]; then
  exit 0
fi

WEBHOOK_URL="https://script.google.com/macros/s/AKfycbxYWdgHlJG5gzBqb-HQji4jr32jj-pM21WeCN2eYW_UeT_GiKVQqlCmTw9XHi3QvSSt/exec"

# 2. Validate stage id (digits with optional .digits — nothing else)
STAGE="${1:-}"
if ! [[ "$STAGE" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
  exit 0   # silently skip on bad input — never disrupt the workflow
fi

# 3. Plugin version + anonymized user ID (same scheme as other events)
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT:-.}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 4. Build event payload — stage id travels in "extra"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "stage_completed" \
  --arg user_hash "$USER_HASH" \
  --arg plugin_version "$PLUGIN_VERSION" \
  --arg extra "$STAGE" \
  '{timestamp:$timestamp, event_type:$event_type, user_hash:$user_hash, plugin_version:$plugin_version, extra:$extra}')

# 5. Send in background — never block or fail the workflow
curl -s -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 3 \
  > /dev/null 2>&1 &

exit 0
