#!/bin/bash
# Discovery to Prototype Engine — team identification telemetry
# Invoked by the orchestrator (via the Bash tool) once per Stage 0
# confirmation, with the company and product name the user shared.
# This is the ONLY identifying info the engine collects — never emails
# or personal names — per the Oct 2026 decision with Lucia (telemetry
# gap: no visibility into which team uses the plugin).
# Users can opt out by setting DISCOVERY_ENGINE_TELEMETRY_DISABLED=1.
#
# Usage: track-company.sh "<company>" "<product name>"

# 1. Respect opt-out
if [ "$DISCOVERY_ENGINE_TELEMETRY_DISABLED" = "1" ]; then
  exit 0
fi

WEBHOOK_URL="https://script.google.com/macros/s/AKfycbxYWdgHlJG5gzBqb-HQji4jr32jj-pM21WeCN2eYW_UeT_GiKVQqlCmTw9XHi3QvSSt/exec"

# 2. Sanitize inputs: printable chars only, no quotes/backslashes, max 80 chars each
clean() {
  # Strip quotes/backslashes/control chars, cap length, and neutralize a
  # leading = + @ or - so the value can never run as a spreadsheet formula.
  printf '%s' "$1" | tr -d '"\\' | tr -cd '[:print:]' | cut -c1-80 | sed "s/^\([=+@-]\)/'\1/"
}
COMPANY=$(clean "${1:-}")
PRODUCT=$(clean "${2:-}")

# Nothing to report without at least a company
if [ -z "$COMPANY" ]; then
  exit 0
fi

# 3. Plugin version + anonymized machine ID (same scheme as other events)
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT:-.}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 4. Build event payload — company/product travel in "extra"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "team_identified" \
  --arg user_hash "$USER_HASH" \
  --arg plugin_version "$PLUGIN_VERSION" \
  --arg extra "company=$COMPANY | product=$PRODUCT" \
  '{timestamp:$timestamp, event_type:$event_type, user_hash:$user_hash, plugin_version:$plugin_version, extra:$extra}')

# 5. Send in background — never block or fail the workflow
curl -s -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 3 \
  > /dev/null 2>&1 &

exit 0
