#!/bin/bash
# Discovery to Prototype Engine — user feedback submission
# Invoked by the discovery-feedback skill (NOT a Claude Code hook).
# Sends a feedback event with rating (1-5) and optional comment.
# Users can opt out by setting DISCOVERY_ENGINE_TELEMETRY_DISABLED=1.
#
# Usage: track-feedback.sh <rating 1-5> [comment]

# 1. Respect opt-out
if [ "$DISCOVERY_ENGINE_TELEMETRY_DISABLED" = "1" ]; then
  echo "Telemetry is disabled. Feedback was NOT sent."
  exit 0
fi

WEBHOOK_URL="https://script.google.com/macros/s/AKfycbxYWdgHlJG5gzBqb-HQji4jr32jj-pM21WeCN2eYW_UeT_GiKVQqlCmTw9XHi3QvSSt/exec"

# 2. Validate rating
RATING="${1:-}"
if ! [[ "$RATING" =~ ^[1-5]$ ]]; then
  echo "Error: rating must be 1, 2, 3, 4, or 5." >&2
  exit 1
fi

# 3. Comment (optional, max 500 chars to keep events lean)
COMMENT="${2:-}"
COMMENT="${COMMENT:0:500}"

# 4. Read plugin version
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT:-.}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")

# 5. Anonymized user ID
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 6. Build payload (no session_id — feedback isn't tied to a specific session lifecycle)
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "feedback" \
  --arg user_hash "$USER_HASH" \
  --arg plugin_version "$PLUGIN_VERSION" \
  --arg rating "$RATING" \
  --arg comment "$COMMENT" \
  '{timestamp:$timestamp, event_type:$event_type, user_hash:$user_hash, plugin_version:$plugin_version, rating:$rating, comment:$comment}')

# 7. Send synchronously so the user gets confirmation
HTTP_STATUS=$(curl -s -L -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 10 \
  -o /dev/null \
  -w "%{http_code}")

# Apps Script quirk: 200, 302, or 405 all indicate the data was written
# (the doPost runs and persists, but the response handling is finicky).
case "$HTTP_STATUS" in
  200|302|405)
    echo "Thanks! Your feedback was submitted."
    ;;
  *)
    echo "Feedback could not be sent (HTTP $HTTP_STATUS). Please try again later or contact Lucia/Cristina."
    exit 1
    ;;
esac
