# Contributors

The **Discovery to Prototype Engine** is built and maintained by the Product Discovery team at Visma, as part of the AI Native Product Development initiative.

## Authors

- **Lucia Wang** — [lucia.wang@visma.com](mailto:lucia.wang@visma.com)
- **Cristina Iftode**

## Acknowledgements

Thanks to everyone at Product Discovery in Visma who has contributed ideas, feedback, and testing as the engine evolved across its phases — Sense (customer insights, competitive landscape, opportunity scoring) and Shape (PRDs, component libraries, prototypes, experiment plans).

## Contributing

This plugin is currently for internal Visma use. For questions, suggestions, or to propose changes, contact the authors above or reach out via the Product Discovery team.
