# Connector Integration Guide

Reference for skill authors on how connectors integrate with the Discovery Engine. Each connector is optional — skills must always work without them.

## Design principle: detect, offer, fallback

Every connector-aware skill follows the same three-step pattern:

1. **Detect** — At the start of the skill, check if the relevant MCP connector is available
2. **Offer** — If connected, offer to pull data directly ("I see you have Intercom connected — want me to pull recent support tickets?")
3. **Fallback** — If not connected, proceed with the manual path (file upload, screenshot, paste, etc.)

The skill's core logic and output format are identical regardless of the data source. Only the input acquisition step changes.

---

## Connector inventory

### Google BigQuery

**Stages:** 1.1 (Customer Insights)

**What it provides:** Direct SQL access to customer analytics tables — NPS scores, CES data, usage metrics, feature adoption rates, churn signals.

**Detection:** Check for BigQuery MCP server availability.

**Integration point:** At the start of Stage 1.1, before data analysis begins.

**Skill behavior when connected:**
- Ask the user which BigQuery project/dataset contains their customer data
- Run exploratory queries to understand table structure
- Pull relevant data directly into the analysis pipeline
- Proceed with the same pain point synthesis and severity scoring as the manual path

**Skill behavior when not connected:**
- Prompt the user to upload CSV files with customer data
- Adapt to whatever column names are present

---

### Intercom

**Stages:** 1.1 (Customer Insights)

**What it provides:** Support tickets, conversation transcripts, customer feedback, CSAT scores, tags, and conversation metadata.

**Detection:** Check for Intercom MCP server availability.

**Integration point:** At the start of Stage 1.1, alongside or instead of BigQuery data.

**Skill behavior when connected:**
- Pull recent conversations, tickets, and feedback tagged with relevant product areas
- Extract pain points directly from conversation content
- Use CSAT/satisfaction data as an additional severity signal
- Combine with any BigQuery data if both are connected

**Skill behavior when not connected:**
- Prompt the user to upload support ticket exports or raw feedback files

---

### Productboard

**Stages:** 1.1 (Customer Insights), 1.2 (Competitive Landscape)

**What it provides:** Feature requests with voting/priority data, customer insights organized by feature area, competitive notes and positioning data, roadmap context.

**Detection:** Check for Productboard MCP server availability.

**Integration point:**
- Stage 1.1: Pull feature requests and customer insights as additional pain point evidence
- Stage 1.2: Pull competitive notes and positioning data to supplement web research

**Skill behavior when connected:**
- Stage 1.1: Pull top feature requests, their associated customer quotes, and priority/impact scores. Merge with other data sources for pain point synthesis
- Stage 1.2: Pull competitive intelligence notes to supplement public web research. Cross-reference Productboard's competitive data with live web search findings

**Skill behavior when not connected:**
- Stage 1.1: Rely on uploaded CSVs or other connected sources
- Stage 1.2: Rely entirely on public web research

---

### Google Drive

**Stages:** All

**What it provides:** Shared file storage for the entire workflow — both reading input files and writing output artifacts.

**Detection:** Check for Google Drive MCP server availability.

**Integration point:** At every stage transition where files are read or written.

**Skill behavior when connected:**
- **Reading:** The orchestrator can pull input files (CSVs, screenshots, prior stage outputs) from a specified Drive folder instead of requiring manual uploads
- **Writing:** All stage output files (opportunity tables, PRDs, prototypes, experiment plans) are saved to a shared Drive folder in addition to the local working directory
- **Benefit:** Teams can collaborate on a shared Drive folder. One person runs `/sense`, saves outputs to Drive. Another person runs `/shape` later and the engine picks up where it left off

**Skill behavior when not connected:**
- Files are uploaded manually and outputs are saved to the local Cowork working directory
- Users download outputs from Cowork to share with teammates

---

### Figma

**Stages:** 4 (Component Library)

**What it provides:** Design tokens (colors, typography, spacing), component specs, screen designs, and layout patterns directly from Figma files.

**Detection:** Check for Figma MCP server availability.

**Integration point:** At the start of Stage 4, as the primary input source.

**Skill behavior when connected:**
- Ask the user for the Figma file URL or project
- Pull design tokens (color palette, typography scale, spacing system)
- Extract component patterns from the design system or key screens
- Build the React component library grounded in actual Figma specs rather than screenshot interpretation

**Skill behavior when not connected:**
- Prompt the user to upload product screenshots
- Infer design tokens and component patterns from the screenshots visually

**Quality impact:** Figma connection produces significantly more accurate component libraries since it works from precise design specs rather than visual inference from screenshots.

---

### Lovable

**Stages:** 5 (Prototype Generator)

**What it provides:** A destination for the generated prototype — Lovable can take the component library and PRD and turn them into a deployable, iterable prototype.

**Detection:** Check for Lovable MCP server availability.

**Integration point:** At the end of Stage 5, after the prototype is generated.

**Skill behavior when connected:**
- After generating the React prototype locally, offer to export the component library and PRD to Lovable
- Push the artifacts to Lovable for the user to refine, iterate, and deploy
- The locally generated prototype still serves as the reference/preview

**Skill behavior when not connected:**
- Generate the React prototype locally as the final artifact
- User can manually copy the code into Lovable or any other tool

---

## Adding a new connector

When adding connector support to a skill:

1. Add the detection step at the top of the skill's SKILL.md (before any data acquisition)
2. Add both the "connected" and "not connected" behavior paths
3. Ensure the skill's output format is identical regardless of which path runs
4. Update `plugin.json` connectors section with the new connector
5. Update this file with the connector's integration details
6. Add a changelog entry (this is a minor version bump)
