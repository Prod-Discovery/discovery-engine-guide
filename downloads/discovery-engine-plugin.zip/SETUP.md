# Setup Instructions

Quick steps to get this plugin published and installable.

## 1. Create the GitHub repo

```bash
gh repo create luciazw-visma/discovery-engine-plugin --private --description "Discovery to Prototype Engine for Claude Cowork"
```

## 2. Copy your skill files

Copy each SKILL.md (and any references/ folders) from your current Cowork skills into the matching `skills/` directory in this repo. The directory structure is already set up — just drop the files in.

```bash
# Example for one skill:
cp /path/to/your/discovery-customer-insights/SKILL.md skills/discovery-customer-insights/
cp -r /path/to/your/discovery-customer-insights/references/ skills/discovery-customer-insights/
```

Repeat for all 9 skills.

## 3. Initialize and push

```bash
cd discovery-engine-plugin
git init
git add .
git commit -m "Initial plugin release v1.0.0 with all skills"
git tag v1.0.0
git remote add origin git@github.com:luciazw-visma/discovery-engine-plugin.git
git push -u origin main
git push origin v1.0.0
```

## 4. Install in Cowork

In Cowork, install the plugin by pointing to the repo URL. All slash commands will register automatically from plugin.json.

## 5. Making updates later

When you change a skill or the workflow:

1. Make your edits in a feature branch
2. Add an entry to `CHANGELOG.md` under a new version heading
3. Update the `version` field in `plugin.json` to match
4. Merge to `main`, then tag the release:

```bash
git tag v1.0.1
git push origin v1.0.1
```

See `CHANGELOG.md` for the versioning guide (what counts as patch vs. minor vs. major).

## 6. Test

Open a fresh Cowork session and try:
- `/discover` — should trigger the full orchestrator
- `/insights` — should trigger standalone customer data analysis
- `/landscape` — should trigger standalone competitive scan
