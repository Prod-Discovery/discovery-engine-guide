# Changelog

All notable changes to the Discovery to Prototype Engine plugin.

## [1.6.0] — 2026-06-08

### Added

- **Anonymous usage telemetry**: the plugin now records three event types — `skill_invoked` (when a skill starts), `session_ended` (when a Claude Code session terminates), and `feedback` (when the user submits a rating + comment). Events include an anonymized per-machine user hash, session ID, and plugin version. No prompts, file contents, names, emails, IPs, or conversation context are ever sent.
- **`discovery-feedback` skill**: a new skill that prompts the user for a 1–5 rating and optional comment, then submits it as an anonymous feedback event. Invoke after a workflow, or any time the user wants to share thoughts.
- **Opt-out**: setting `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` in the shell disables all telemetry. Documented in `README.md`.

### Internal

- `hooks/hooks.json` registers `PostToolUse` (matcher: `Skill`) and `SessionEnd` hooks.
- Hook scripts: `hooks/track-usage.sh`, `hooks/track-session-end.sh`, `hooks/track-feedback.sh`.

## [1.5.1] — 2026-06-08

### Fixed

- **Author field**: replaced non-standard `authors` array in `plugin.json` with the spec-compliant `author` singular object. Cowork now correctly displays the author name ("Lucia Wang") on the plugin tile.
- Cristina Iftode credited in `README.md` and the new `CONTRIBUTORS.md`.

## [1.5.0] — 2026-06-08

### Changed

- **Display name**: added `displayName: "Discovery to Prototype Engine"` to both `plugin.json` and the marketplace entry. The slug `discovery-engine-plugin` is unchanged, so skill namespaces and installed-state remain stable.
- **Description**: updated copy to highlight the 6-stage agentic workflow and connector compatibility (Figma, data exports, feedback platforms).

## [1.4.0] — 2026-04-21

### Architecture

- **Two-phase workflow structure**: Reorganized the engine into Sense (Stages 0–2) and Shape (Stages 3–6) phases for clearer mental model
- **File-based state management**: Every stage now writes structured output files to `/home/claude/discovery-engine/`. This replaces reliance on conversation context and enables cross-session resume, team handoffs, and subagent execution in Cowork
- **Environment-aware execution**: Orchestrator auto-detects whether subagents are available (Cowork) or not (Claude.ai chat) and adapts — running Stages 1.1 and 1.2 in parallel or sequentially
- **Google Drive integration**: When connected, stage outputs are saved to a shared Drive folder alongside local files, enabling team handoffs across sessions

### New Skills

- **`discovery-getting-started`**: Quick-start orientation skill for new users. Explains the engine, shows all commands, and hands the user the exact phrase to begin
- **`discovery-agent-prd`** (Stage 3.2+3.3): Agentic PRD path — designs agent behavior (triggers, actions, decision logic, boundaries, failure modes) before writing the PRD. Includes behavior design guide and agent PRD template

### Updated Skills

- **`discovery-to-prototype-engine`** (Orchestrator): Major rewrite. Now handles Stage 0 context ingestion, Stage 1.3 opportunity merging (internal), auto-routing between agentic and non-agentic PRD paths, downloadable artifact presentation at every checkpoint, and connected tool auto-detection (Intercom, Figma, Productboard, BigQuery, Google Drive)
- **`discovery-competitive-landscape`** (Stage 1.2): Now uses Kano-style categories (must-haves, should-haves, delighters, performance benefits, adoption tactics, limitations) and outputs signal strength ratings
- **`discovery-solution-prioritization`** (Stage 2): Split into two explicit phases — 2a (scoring) and 2b (solution exploration). Added agentic/non-agentic flagging on solution concepts to drive Stage 3 branching. New reference files: scoring framework, output example, solution exploration guide
- **`discovery-component-library`** (Stage 4): Now supports 5 input methods with auto-detection priority: existing local repo, AI-readable design system files, Figma connection, GitHub design system, product screenshots
- **`discovery-customer-insights`** (Stage 1.1): Outputs now include user segments and business impact alongside severity scores
- **`discovery-experiment-plan`** (Stage 6): Added test script template reference file
- **`discovery-prd-foundation`** (Stage 3.1): Added PRD template reference file

### Stage Outputs & Artifacts

- All stages now produce downloadable artifacts via `present_files` after checkpoint confirmation
- Stage output files follow a consistent naming convention: `stage-X-Y-name.md`
- Orchestrator reads output files (not conversation history) at each stage transition for canonical state

### Connected Tool Support

- Auto-detects Intercom, HubSpot, BigQuery, Productboard, Figma, and Google Drive at Stage 0
- Uses `search_mcp_registry` and `suggest_connectors` to offer one-click connector setup
- Falls back gracefully to manual upload when connectors aren't available

## [1.0.0] — Initial Release

- 6-stage sequential workflow: Data Synthesis → Opportunity Scoring → PRD → Component Library → Prototype → Experiment Plan
- Checkpoint-based execution with human review at each stage
- Validated end-to-end on Oima (Finnish welfare management system)
