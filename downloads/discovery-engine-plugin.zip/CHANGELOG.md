# Changelog

All notable changes to the Discovery to Prototype Engine plugin.

## [1.9.0] - 2026-10-22

### Added

- **Agent patterns add-on** (`discovery-agent-patterns`), an optional skill for the agentic path that applies Visma's [Agent Design Guidelines](https://agent-design-guidelines-dqrlkyvm4a-nw.a.run.app/) (by Amanda Lundius, Nicolae Socaciu and Diana Almeida). Two modes:
  - **Pattern check**, after the agent PRD: picks the 5 to 7 patterns this agent needs from its behaviour script, sets a level per task in the guidelines' words (Off, Suggest, Ask first, Auto), shown beside the agent's autonomy level from Stage 3, which is unchanged, and shows the patterns as 4 to 5 design moments in the user's flow, each linked to its page in the patterns library. Saved as `stage-3-pattern-card-[feature].md`.
  - **Pattern audit**, after the prototype: pass, partial or gap per pattern, with evidence from the prototype. Fixes only on request. Saved as `stage-5-pattern-audit-[feature].md`.
  - Both modes also run standalone on any agent PRD, spec or prototype.
- **Always the current patterns.** Each time it runs, the add-on reads the live `patterns.json` from the guidelines repo on GitHub, so pattern changes reach every install, including ZIP installs that never update. Offline, or if the repo can't be read, it uses the bundled copy (`skills/discovery-agent-patterns/references/patterns.md`) and says which source it used. Patterns removed from the guidelines are skipped, never cited.
- The bundled copy is rebuilt by `scripts/sync_patterns.py` from the guidelines' `patterns.json`, using the guidelines' own generator. A daily workflow (`sync-patterns.yml`) runs it and opens a pull request when the pattern text changed; commits that change no pattern text are ignored. The release workflow warns when the copy is behind.
- Telemetry: the pattern check and the audit are recorded as stages `3.5` and `5.5` when their files are saved, the same way as every other stage.

### Changed

- **Stage 3's exit on the agentic path**: after the agent PRD is approved, the engine now recommends the optional pattern check first, and only points to Stage 4 (Component Library) once the check is done or the user says "not now". Previously it pointed straight to Stage 4. The offer now says plainly that it checks the agent's UI patterns against Visma's Agent Design Guidelines.
- **Stage 5 on the agentic path**: if a Pattern Card exists, the prototype builds its design moments in. After an agentic prototype is approved, the engine offers the optional pattern audit before Stage 6.
- The orchestrator makes the same two offers at the same two points for people running the full workflow.

### Changed after preview testing (Amanda and Diana)

- **Pattern audit treats everything you upload as one agent**: prototype, agent instructions, PRD or spec. One set of verdicts, each naming the file it comes from. New verdict "Pass (described, not shown)" when only the instructions or PRD cover a pattern.
- **No score in the plugin.** The audit gives verdicts only and points to Assess your agent on the guide's website for the official score, so the two never disagree. Without a Pattern Card, the audit no longer reports patterns the agent doesn't need as gaps.
- **Clearer journey**: the start map shows the standard path and the agent path with its two optional steps. The engine says which path you're on after you pick a solution, and every checkpoint starts with a progress line.
- **The Pattern Card is explained** before you save it, and the card says what it's for.
- **Buttons** for choices and next steps where Cowork supports them, with the lettered list as the fallback.
- **Renamed** to Visma's guide for Great Agentic Experiences in all plugin text. The old name still works as a trigger phrase.

### Opt-in

The add-on never runs unless the user chooses it. Declining drops it without further prompts. The non-agentic path is unchanged and never sees it.

## [1.8.1] — 2026-10-09

### Changed

- **One starter skill**: `discovery-getting-started` is retired; `discovery-engine-start` now also answers orientation questions ("what is this plugin", "help", "what can this do") — always ending in a concrete next step, not just an explanation.
- **No more double welcome**: when you arrive at the full workflow from `discovery-engine-start`, the orchestrator skips its own welcome screen and goes straight to the context questions, reusing everything the readiness scan already found.
- **Releases are now manual only**: pushing to the repository never publishes; every release is a deliberate, reviewed step.

### Added

- `stage_completed` events now carry the session ID, so stage progress can be tied to a run.
- `discovery-engine-start` anonymously records which route the user chooses (full workflow, jump/resume, or a single skill), once per session.
- Free-text telemetry fields (feedback comments, company/product names) strip control characters and neutralize leading formula characters, so nothing sent can execute in a spreadsheet.
- The orchestrator now invokes stage skills via the Skill tool instead of inlining their work, so full-workflow usage is visible in the data.

### Removed

- **Opportunity Radar pulled from the published plugin.** It's being reworked and tested on live data with pilot teams first (scored table, cited evidence, one live data source), and returns in a future release once it has earned its place. Development continues on the `feature/discovery-radar` branch.

## [1.8.0] — 2026-10-07

### Added

- **Front door skill (`discovery-engine-start`)**: say "Start the discovery engine" and it silently detects what you already have (previous runs with the exact resume point, data files, connected tools, design system, plugin version), shows a plain-language readiness checklist and the journey map, and routes you to your one next step via a closed A/B/C choice.
- **Opportunity Radar (`discovery-radar`)**: scheduled, recurring discovery. Scans your customer feedback weekly or monthly, compares against the last digest, and delivers a short "what's new, what's growing" digest with a one-phrase handoff into the full engine. Delivery to Slack or email (plus the digest file); includes a no-setup demo on bundled sample data ("radar demo"). Introduced in the Stage 0 welcome screen, after the Top 5, and at the end of Stage 6.
- **Company and product question in Stage 0**: an optional question about which company and product the run is for, so the maintainers can see which Visma teams use the engine. Fully optional; declining sends nothing.
- **Standalone-use sections for stages 4, 5, and 6**: every stage skill now works on its own without earlier stage files — no skill forces you into the full workflow.

### Fixed

- **Stage and feedback telemetry never arrived from real installs.** The old mechanism asked the model to run a tracking script via Bash, which failed everywhere: the script path variable is unset in that context, and default permission mode blocks the call. Progress telemetry is now sent by a plugin hook that fires when a stage's output file is saved — no extra permission prompts, deduplicated per session. Feedback submission was rebuilt the same way.
- **Session-end event flooding**: `session_ended` now sends at most once per day per machine (it was ~97% of all collected rows while adding no signal).
- Radar example digest counts corrected to match the bundled sample CSV.

### Changed

- Stage 3 and Stage 6 output filenames standardized to a `stage-N-` prefix (e.g. `stage-3-prd-<feature>.md`, `stage-6-experiment-plan.md`), matching Stage 5.
- Radar setup asks every question as a lettered A/B/C list, so you answer with a single character.
- Trigger phrases split between the explainer (`discovery-getting-started`: "what is this plugin") and the front door ("where do I start", "what's my next step").
- README: front door and radar added to the skills table and Quick Start; telemetry disclosure updated to cover all five event types honestly, including exactly what the optional company question sends.

## [1.7.0] — 2026-07-06

### Changed

- **Prototypes are now a single standalone HTML file** (Stage 5). Double-click to open in any browser — no Node.js, npm, or build step. React loads from CDN; components, design tokens, and sample data are all inlined. The file can be shared over Slack/email and opened by usability-test participants directly. This closes the biggest gap found in the July review: prototypes that non-technical stakeholders couldn't actually view.

### Added

- **Wizard-of-Oz mode for agentic prototypes** (Stage 5): when the PRD contains an Agent Behavior Script, the prototype simulates the agent — scripted state transitions, a visible "agent activity" panel, real approval screens at every human checkpoint, and one scripted failure mode — making agent behavior designs testable with real users.
- **Stage-completion funnel telemetry**: every stage checkpoint now logs an anonymous `stage_completed` event (stage number only — no content), so we can see where users drop off in the workflow. New `hooks/track-stage.sh`; respects the existing `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` opt-out.
- **Participant screener** requirements in the Stage 6 experiment plan: must-have/exclusion criteria derived from the PRD's target audience, non-leading screener questions, recruiting buffer for no-shows.
- **"Analyzing Results" guidance** in Stage 6: same-day debriefs, evidence grid, 3+ participant pattern threshold, scoring the hypothesis against pre-committed criteria, and feeding findings back into the PRD.
- **Operationalized success criteria** in Stage 6: explicit definitions of "complete" and "without help", and honest framing of 5–8-participant results as directional rather than statistical.

### Internal

- Release workflow now publishes `downloads/version.json` (version + release date) to the guide repo, shown in the guide's download box.

## [1.6.2] — 2026-07-02

### Added

- **Feedback is now discoverable**: the orchestrator's welcome message and the getting-started guide both tell users they can type "give feedback" at any moment — anonymous 1–5 rating plus optional comment — without needing to finish a workflow first. Until now the feedback skill existed but users had no way to know about it.

## [1.6.1] — 2026-07-02

### Fixed

- **Created five missing reference files** that skills cited but that never existed, causing Claude to improvise formats inconsistently between runs:
  - `discovery-customer-insights/references/data-schema.md` — expected CSV formats and column mappings for all five data types
  - `discovery-customer-insights/references/output-example.md` — worked example of the Top 5 opportunity table
  - `discovery-competitive-landscape/references/kano-framework.md` — full categorization guide with definitions, examples, and heuristics
  - `discovery-competitive-landscape/references/output-example.md` — complete example table + gap summary
  - `discovery-to-prototype-engine/references/opportunity-merge-template.md` — exact Stage 1.3 output format
- **Environment guards**: every `present_files` call site now has a fallback for environments where the function is unavailable; the orchestrator's connector detection no longer errors when `search_mcp_registry`/`suggest_connectors` are missing; the competitive landscape skill now handles web search being unavailable instead of failing silently.
- **Stage 2 output path**: `discovery-solution-prioritization` now states the full output path (`/home/claude/discovery-engine/stage-2-selected-opportunity.md`) instead of "as already specified", fixing standalone runs.

## [1.6.0] — 2026-06-08

### Added

- **Anonymous usage telemetry**: the plugin now records three event types — `skill_invoked` (when a skill starts), `session_ended` (when a Claude Code session terminates), and `feedback` (when the user submits a rating + comment). Events include an anonymized per-machine user hash, session ID, and plugin version. No prompts, file contents, names, emails, IPs, or conversation context are ever sent.
- **`discovery-feedback` skill**: a new skill that prompts the user for a 1–5 rating and optional comment, then submits it as an anonymous feedback event. Invoke after a workflow, or any time the user wants to share thoughts.
- **Opt-out**: setting `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` in the shell disables all telemetry. Documented in `README.md`.

### Internal

- `hooks/hooks.json` registers `PostToolUse` (matcher: `Skill`) and `SessionEnd` hooks.
- Hook scripts: `hooks/track-usage.sh`, `hooks/track-session-end.sh`, `hooks/track-feedback.sh`.

## [1.5.1] — 2026-06-08

### Fixed

- **Author field**: replaced non-standard `authors` array in `plugin.json` with the spec-compliant `author` singular object. Cowork now correctly displays the author name ("Lucia Wang") on the plugin tile.
- Cristina Iftode credited in `README.md` and the new `CONTRIBUTORS.md`.

## [1.5.0] — 2026-06-08

### Changed

- **Display name**: added `displayName: "Discovery to Prototype Engine"` to both `plugin.json` and the marketplace entry. The slug `discovery-engine-plugin` is unchanged, so skill namespaces and installed-state remain stable.
- **Description**: updated copy to highlight the 6-stage agentic workflow and connector compatibility (Figma, data exports, feedback platforms).

## [1.4.0] — 2026-04-21

### Architecture

- **Two-phase workflow structure**: Reorganized the engine into Sense (Stages 0–2) and Shape (Stages 3–6) phases for clearer mental model
- **File-based state management**: Every stage now writes structured output files to `/home/claude/discovery-engine/`. This replaces reliance on conversation context and enables cross-session resume, team handoffs, and subagent execution in Cowork
- **Environment-aware execution**: Orchestrator auto-detects whether subagents are available (Cowork) or not (Claude.ai chat) and adapts — running Stages 1.1 and 1.2 in parallel or sequentially
- **Google Drive integration**: When connected, stage outputs are saved to a shared Drive folder alongside local files, enabling team handoffs across sessions

### New Skills

- **`discovery-getting-started`**: Quick-start orientation skill for new users. Explains the engine, shows all commands, and hands the user the exact phrase to begin
- **`discovery-agent-prd`** (Stage 3.2+3.3): Agentic PRD path — designs agent behavior (triggers, actions, decision logic, boundaries, failure modes) before writing the PRD. Includes behavior design guide and agent PRD template

### Updated Skills

- **`discovery-to-prototype-engine`** (Orchestrator): Major rewrite. Now handles Stage 0 context ingestion, Stage 1.3 opportunity merging (internal), auto-routing between agentic and non-agentic PRD paths, downloadable artifact presentation at every checkpoint, and connected tool auto-detection (Intercom, Figma, Productboard, BigQuery, Google Drive)
- **`discovery-competitive-landscape`** (Stage 1.2): Now uses Kano-style categories (must-haves, should-haves, delighters, performance benefits, adoption tactics, limitations) and outputs signal strength ratings
- **`discovery-solution-prioritization`** (Stage 2): Split into two explicit phases — 2a (scoring) and 2b (solution exploration). Added agentic/non-agentic flagging on solution concepts to drive Stage 3 branching. New reference files: scoring framework, output example, solution exploration guide
- **`discovery-component-library`** (Stage 4): Now supports 5 input methods with auto-detection priority: existing local repo, AI-readable design system files, Figma connection, GitHub design system, product screenshots
- **`discovery-customer-insights`** (Stage 1.1): Outputs now include user segments and business impact alongside severity scores
- **`discovery-experiment-plan`** (Stage 6): Added test script template reference file
- **`discovery-prd-foundation`** (Stage 3.1): Added PRD template reference file

### Stage Outputs & Artifacts

- All stages now produce downloadable artifacts via `present_files` after checkpoint confirmation
- Stage output files follow a consistent naming convention: `stage-X-Y-name.md`
- Orchestrator reads output files (not conversation history) at each stage transition for canonical state

### Connected Tool Support

- Auto-detects Intercom, HubSpot, BigQuery, Productboard, Figma, and Google Drive at Stage 0
- Uses `search_mcp_registry` and `suggest_connectors` to offer one-click connector setup
- Falls back gracefully to manual upload when connectors aren't available

## [1.0.0] — Initial Release

- 6-stage sequential workflow: Data Synthesis → Opportunity Scoring → PRD → Component Library → Prototype → Experiment Plan
- Checkpoint-based execution with human review at each stage
- Validated end-to-end on Oima (Finnish welfare management system)
