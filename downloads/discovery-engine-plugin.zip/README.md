# Discovery to Prototype Engine

A Claude plugin (works in Claude Code and the Cowork tab of the Claude Desktop app) that transforms raw customer feedback and competitive intelligence into a testable interactive prototype — in hours instead of weeks.

Built for product managers and designers who want to run continuous discovery without the manual overhead. The engine guides you through a checkpoint-based workflow across two phases: **Sense** (understand the landscape) and **Shape** (build the response).

## Where it runs

| Surface | Supported? |
|---|---|
| Claude Code CLI (terminal) | ✅ |
| Claude Desktop app — **Cowork** tab | ✅ |
| Claude Desktop app — **Code** tab | ✅ |
| claude.ai chat (consumer website at claude.ai/chat) | ❌ no plugin system on that surface |

## How It Works

```
SENSE — Understand the landscape
  Stage 0    Set up product context (strategy docs, pitch decks, or Q&A)
  Stage 1.1  Analyze customer data (pNPS, CES, support tickets, feedback)
  Stage 1.2  Research competitors and find market gaps
  Stage 1.3  Merge both into your Top 5 Opportunities (automatic)
  Stage 2    Score opportunities, pick one, and commit to a solution direction

SHAPE — Build the response
  Stage 3    Write the PRD (auto-routes to standard or agentic PRD)
  Stage 4    Build or connect your component library
  Stage 5    Generate an interactive React prototype
  Stage 6    Create an experiment plan and usability test script
```

Every stage pauses at a checkpoint for your review. You approve, adjust, or stop before the engine proceeds. Outputs are saved as files at each stage, so you can resume later or share with teammates.

## What's in the Plugin

### Skills

| Skill | Stage | What It Does |
|-------|-------|-------------|
| `discovery-to-prototype-engine` | 0 (Orchestrator) | Master workflow orchestrator. Ingests product context, runs all stages with checkpoints, manages state via output files. |
| `discovery-customer-insights` | 1.1 | Ingests multi-source customer data (pNPS, CES, support tickets, feedback, usage data) and synthesizes pain points with severity scoring. |
| `discovery-competitive-landscape` | 1.2 | Researches competitors using public sources. Structures findings into a Kano-style gap analysis table. |
| `discovery-solution-prioritization` | 2 | Two-phase: scores opportunities on pain intensity, market size, feasibility, and strategic alignment — then explores solution concepts for the selected opportunity. |
| `discovery-prd-foundation` | 3.1 | Creates a concise PRD for non-agentic solutions: problem statement, solution concept, user flows, success metrics. |
| `discovery-agent-prd` | 3.2+3.3 | Agentic path: designs agent behavior first (triggers, actions, decision logic, boundaries, failure modes), then creates a PRD incorporating the confirmed behavior script. |
| `discovery-component-library` | 4 | Builds or connects a reusable React component library. Supports 5 input methods: existing repo, AI-readable design system files, Figma, GitHub design system, or product screenshots. |
| `discovery-prototype-generator` | 5 | Generates an interactive React prototype from PRD + component library. |
| `discovery-experiment-plan` | 6 | Creates experiment plan and usability test script: assumptions, hypothesis, test method, success criteria, and interview script. |
| `discovery-getting-started` | — | Quick-start orientation. Explains the engine and hands you the exact phrase to begin. |
| `discovery-feedback` | — | Collects an anonymous 1–5 rating + optional comment from the user. Invoke after a workflow, or whenever the user wants to share thoughts. |

### Reference Files

Several skills include reference templates and guides in their `references/` folders:

- **Scoring framework** and **output example** for opportunity prioritization (Stage 2)
- **Solution exploration guide** for brainstorming solution concepts (Stage 2)
- **PRD template** for product requirements (Stage 3.1)
- **Agent behavior design guide** and **agent PRD template** for agentic solutions (Stage 3.2+3.3)
- **Test script template** for usability testing (Stage 6)

## Installation

There are two ways to install, depending on which Claude product you use. Pick whichever fits.

### Option 1 — Claude Desktop app (Cowork tab) — easiest, no terminal

Best for designers, PMs, and anyone who'd rather not touch a terminal. Walks you through it visually.

See the [Quick Start Guide](https://prod-discovery.github.io/discovery-engine-guide/) for a step-by-step with screenshots. The short version:

1. Download the plugin `.zip` from the [Quick Start Guide](https://prod-discovery.github.io/discovery-engine-guide/) (the download button is in Step 01).
2. Open the **Claude Desktop app** → switch to the **Cowork** tab.
3. **Customize** (left sidebar) → **+ Add plugin** → **+ Create plugin** → **Upload plugin**.
4. Select the `.zip` file. Click **Upload**, then confirm.
5. Done. The engine's skills now show up in your `/` command menu.

> Do not unzip the file before uploading — upload the full `.zip` as-is.

### Option 2 — Claude Code (CLI or Desktop app's Code tab) — for technical users

From inside a Claude Code session:

```text
/plugin marketplace add Prod-Discovery/discovery-engine-plugin
/plugin install discovery-engine-plugin@prod-discovery
```

The plugin auto-updates on next launch whenever a new version is pushed.

For external collaborators (not in the Visma org), the repo needs to be public OR they need to be added as a GitHub collaborator first. The CLI uses your local `gh auth login` credentials for private repos.

## Quick Start

After installing, say:

> "Run the full discovery to prototype workflow"

The engine walks you through every stage starting with product context. You don't need everything ready upfront — it asks for what it needs at each step.

Or jump to any stage directly:

| Say this... | To do this... |
|-------------|---------------|
| "Run the full discovery to prototype workflow" | Start from the beginning |
| "Jump to Stage [N]" | Start at a specific stage |
| "Analyze this customer data" | Run Stage 1.1 only |
| "Research competitors" | Run Stage 1.2 only |
| "Score these opportunities" | Run Stage 2 only |
| "Create a PRD for [opportunity]" | Run Stage 3 only |
| "Build component library" | Run Stage 4 only |
| "Generate prototype" | Run Stage 5 only |
| "Create test plan" | Run Stage 6 only |

## What You'll Need

You don't need all of this upfront — the engine asks at each stage:

| Input | When | Format |
|-------|------|--------|
| Product context | Stage 0 | Strategy doc, pitch deck, or answers to questions |
| Customer data | Stage 1.1 | CSV exports (NPS, support tickets, feedback) |
| Competitor names | Stage 1.2 | 2–4 names — the engine researches them |
| Component library or screenshots | Stage 4 | Existing repo, Figma, design system files, or product screenshots |

## Key Design Principles

- **Modular + chainable**: Each stage works independently and as part of the full chain
- **Checkpoints everywhere**: You review and approve before proceeding — corrections early save time later
- **Context-grounded scoring**: Stage 2 gathers business context before scoring to prevent assumptions
- **State via files**: Every stage writes structured output files, enabling resume, team handoffs, and cross-session continuity
- **Environment-aware**: When subagents are available (Claude Code, Cowork), the engine runs eligible stages in parallel. When they're not, it falls back to running stages sequentially.

## Connected Tool Support

The engine auto-detects connected tools and offers to use them:

- **Intercom / HubSpot / BigQuery** → Pull customer data directly at Stage 1.1
- **Productboard** → Supplement customer insights and competitive research
- **Figma** → Connect your design system directly at Stage 4
- **Google Drive** → Save outputs to a shared folder for team handoffs

## Telemetry

This plugin sends **anonymized usage events** to help the maintainers understand which parts of the workflow are useful and prioritize improvements. Three event types are collected:

- **`skill_invoked`** — fired when you start one of the engine's skills. Records: skill name, timestamp, anonymized user hash, session ID, plugin version.
- **`session_ended`** — fired once per Claude Code session, when the session terminates. Records: timestamp, anonymized user hash, session ID, plugin version, reason the session ended.
- **`feedback`** — fired only when you explicitly run the `discovery-feedback` skill. Records: rating (1–5), optional comment (truncated to 500 characters), anonymized user hash, plugin version.

The "anonymized user hash" is a 12-character one-way hash of your username and hostname — stable per machine, but not reversible into anything that identifies you personally.

**No prompts, file contents, real names, emails, IPs, project names, customer data, or conversation content are ever sent.**

### Opting out

Set this environment variable in your shell config (`~/.zshrc`, `~/.bashrc`, or `~/.profile`):

```bash
export DISCOVERY_ENGINE_TELEMETRY_DISABLED=1
```

Then restart Claude Code. The telemetry hooks will silently skip without sending any events. Opt-out applies to all three event types including the feedback skill.

## Version

**v1.6.0** — See [CHANGELOG.md](CHANGELOG.md) for details.

## Authors

- **Lucia Wang** — [lucia.wang@visma.com](mailto:lucia.wang@visma.com)
- **Cristina Iftode**

Built at Product Discovery in Visma, as part of the AI Native Product Development initiative. See [CONTRIBUTORS.md](CONTRIBUTORS.md) for full credits.

## License

Internal use — Visma product teams.
