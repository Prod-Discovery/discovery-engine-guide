# Agent Behavior Design Guide

Reference for Step 1 of the Agent PRD skill. Use this guide to produce a complete, reviewable, one-page Agent Behavior Script.

---

## What Makes a Good Behavior Script

A behavior script is a one-page specification for how an agent operates. It should be:
- **Concrete enough** that a developer could implement it without ambiguity
- **Clear enough** that a PM or designer can review and validate it
- **Bounded enough** that failure modes and edge cases are addressed upfront

The script is NOT code — it's a structured description of logic, written for humans.

---

## The Behavior Design Prompt

This is the core prompt used to generate the behavior script. Fill in the context variables from Stage 2 and product context:

```
Context:
- Chosen opportunity: [from Stage 2]
- Autonomy level: [confirmed level]
- Primary user: [from product context]
- Desired outcome: [what success looks like]

Define the behavior of the agent or system for this opportunity.
Adapt framing to the autonomy level: use "system" for deterministic workflows,
"assistant" for copilot-level, and "agent" for autonomous approaches.

Structure the output as follows:

1. Goal
   What does the agent/system achieve?
   State as a measurable outcome (e.g., "reduce ticket triage time from 15 min
   to under 2 min with 90% routing accuracy").

2. Inputs & Triggers
   What data, events, or user actions activate the workflow?
   What context does it need from other systems?

3. Tools Required
   List each system or data source the agent must access and what it uses it for.
   Note if access is read or read-write.

4. Human Checkpoints
   Identify the critical moments where a human must step in.
   For each, state what the human does (initiates / reviews & approves /
   overrides / makes the final call) and why.

5. Evaluation
   How do we know it worked?
   Define the completion signal, 2-3 failure scenarios, and the fallback for each.

Format the workflow and human checkpoints as a concise table.
Keep the full output to one page.
Be specific about tools — name actual systems from the product context.
Do not over-specify for simple workflows or under-specify for autonomous agents.
```

---

## Behavior Script Template

```markdown
# Agent Behavior Script: [Solution Name]

## Identity
- **Autonomy Level**: [Chatbot / Copilot / Assistant / Agent]
- **Purpose**: [One sentence — what this agent does]
- **Operates within**: [Which product area or workflow]

## Goal
[Measurable outcome statement]

## Inputs & Triggers

| Trigger | Condition | Frequency |
|---------|-----------|-----------|
| [What activates it] | [Specific condition] | [How often] |

## Tools Required

| System | Access | Used For |
|--------|--------|----------|
| [System name] | Read | [What it reads] |
| [System name] | Read-write | [What it reads and writes] |

## Human Checkpoints

| Moment | Human Action | Reason |
|--------|-------------|--------|
| [When in the workflow] | [Initiates / Reviews & approves / Overrides / Makes final call] | [Why human is needed] |

## Evaluation

| Item | Description |
|------|-------------|
| **Completion Signal** | [How we know it's done] |
| **Failure 1** | [What fails] → [Fallback: retry / escalate / rollback / notify] |
| **Failure 2** | [What fails] → [Fallback] |
| **Failure 3** | [What fails] → [Fallback] |
```

---

## Autonomy Level Reference

Use this to calibrate the behavior design. The confirmed level from Step 1a determines the depth and style of the behavior script.

| Level | Framing | Actions | Human Role | Script Depth |
|-------|---------|---------|------------|-------------|
| **Chatbot** | "System" | Responds to queries only | User initiates every interaction | Light — mostly Q&A logic |
| **Copilot** | "Assistant" | Suggests actions, surfaces insights | User decides and acts on every suggestion | Moderate — define suggestion triggers and display |
| **Assistant** | "Assistant" | Executes simple tasks on request | User initiates; reviews results | Moderate-high — define task boundaries and reversibility |
| **Agent** | "Agent" | Plans, decides, executes autonomously | Reviews at checkpoints; overrides on exceptions | Full — define triggers, decision logic, boundaries, failures |

---

## Design Principles

### 1. Start with triggers, not actions
Define WHEN the agent activates before defining WHAT it does. This prevents building an agent that's always on or that solves problems nobody triggered.

### 2. Every action needs a boundary
For each action the agent can take, define at least one condition under which it should NOT take that action. This prevents unbounded autonomy.

### 3. Human checkpoints are mandatory
Even fully autonomous agents need human touchpoints. Define where and why.

### 4. Failure modes are not optional
Every agent will fail. Define the most likely failures and how the agent handles them BEFORE the user encounters them.

### 5. Be specific about tools
Name actual systems from the product context (e.g., "Intercom inbox," "Zendesk ticket queue," "PostgreSQL database"). Generic references like "the data source" are too vague for implementation.

### 6. Test with the "3 AM rule"
Ask: "If this agent ran at 3 AM with no one watching, what's the worst it could do?" The answer should always be "something recoverable."

---

## Common Agent Patterns

### Pattern: Monitor + Alert
- **Level**: Copilot
- **Trigger**: Threshold crossed or condition detected
- **Action**: Notify user with context and suggested action
- **Boundary**: Never takes action itself; only alerts
- **Example**: Alert when support ticket volume spikes above 2x normal

### Pattern: Triage + Route
- **Level**: Assistant
- **Trigger**: New item arrives (ticket, request, document)
- **Action**: Categorize, prioritize, route to appropriate handler
- **Boundary**: Never resolves the item; only routes it
- **Example**: Auto-categorize and assign incoming support tickets

### Pattern: Draft + Review
- **Level**: Assistant
- **Trigger**: User requests or event triggers
- **Action**: Generate a draft (response, document, plan), present for review
- **Boundary**: Never sends/publishes without user confirmation
- **Example**: Draft email responses to common support patterns

### Pattern: Auto-execute + Audit
- **Level**: Agent
- **Trigger**: Routine task on schedule or event
- **Action**: Complete the task autonomously, log what it did
- **Boundary**: Only handles routine cases; escalates exceptions
- **Example**: Auto-reconcile bank transactions with >95% match confidence
