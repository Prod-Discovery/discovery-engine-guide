---
name: discovery-agent-prd
description: "Stage 3.2+3.3 (agentic path) of Discovery to Prototype Engine. Designs agent behavior first (triggers, actions, decision logic, boundaries, failure modes), pauses for user review, then creates a concise PRD incorporating the confirmed behavior script. Use when user says 'design agent behavior', 'create agentic PRD', 'run agentic stage 3', 'agent behavior design', or when Stage 2 outputs an agentic solution concept. Also triggers when user has an agentic opportunity and wants to specify how the agent should behave before writing requirements. Outputs structured PRD with embedded agent behavior script for prototype generation."
---

# Discovery Agent PRD (Stage 3.2+3.3 — Agentic Path)

Handles the agentic branch end-to-end in two steps with a hard checkpoint between them. First designs the agent's behavior and produces a one-page Agent Behavior Script (Step 1), pauses for user review and confirmation, then produces a concise PRD that incorporates the confirmed behavior script (Step 2).

This is the agentic branch of Stage 3. For non-agentic solutions, see `discovery-prd-foundation`.

## Prerequisites

Requires a selected opportunity and committed agentic solution concept from Stage 2 (Solution Prioritization), or user-provided:
- Problem description and solution concept (flagged as agentic)
- Target user segment and business impact context
- Product context (target audience, market, business goals, systems used)

---

## Step 1: Agent Behavior Design

### Purpose

Define exactly what the agent does, where humans stay in control, and what failure looks like — before any PRD or prototype work begins. The output is a structured, one-page Agent Behavior Script.

### 1a: Confirm Autonomy Level

Before designing behavior, confirm the appropriate autonomy level with the user:

```
The selected solution was flagged as agentic in Stage 2.

Quick check before we design the behavior:
- Does the agent need to take action autonomously, or mostly inform/recommend?
- Are there regulatory, trust, or compliance reasons to keep a human in the loop?
- What's the worst-case outcome if the agent gets it wrong?

Confirm: which autonomy level fits best?
```

#### Autonomy Level Reference

| Level | What It Means in Practice |
|-------|--------------------------|
| **Chatbot** | Answers questions. No actions taken. No data written. |
| **Copilot** | Surfaces personalised suggestions. Human decides and acts. |
| **Assistant** | Completes simple, reversible tasks on explicit user request. Human-initiated. |
| **Agent** | Plans and executes multi-step workflows. Alerts human only at key checkpoints or on exceptions. |

Adapt all downstream framing to the confirmed level: use "system" for deterministic workflows, "assistant" for copilot-level, and "agent" for autonomous approaches.

### 1b: Design Behavior

Use this prompt structure to generate the Agent Behavior Script:

```
Context:
- Chosen opportunity: [from Stage 2]
- Autonomy level: [confirmed level]
- Primary user: [from product context]
- Desired outcome: [what success looks like]

Define the behavior of the agent or system for this opportunity.

Structure the output as follows:

1. Goal
   What does the agent/system achieve?
   State as a measurable outcome (e.g., "reduce ticket triage time from 15 min
   to under 2 min with 90% routing accuracy").

2. Inputs & Triggers
   What data, events, or user actions activate the workflow?
   What context does it need from other systems?

3. Tools Required
   List each system or data source the agent must access and what it uses it for.
   Note if access is read or read-write.

4. Human Checkpoints
   Identify the critical moments where a human must step in.
   For each, state what the human does (initiates / reviews & approves /
   overrides / makes the final call) and why.

5. Evaluation
   How do we know it worked?
   Define the completion signal, 2-3 failure scenarios, and the fallback for each.
```

**Guidelines for the behavior design prompt:**
- Format the workflow and human checkpoints as a concise table
- Keep the full output to one page
- Be specific about tools — name actual systems from the product context
- Do not over-specify for simple workflows or under-specify for autonomous agents

### 1c: Output the Behavior Script

Deliver as a structured one-page document:

**Agent Behavior Script: [Solution Name]**

| Field | Content |
|-------|---------|
| **Autonomy Level** | [Confirmed level] |
| **Goal** | [Measurable outcome] |
| **Trigger** | [What starts it] |
| **Inputs** | [Data / events needed] |
| **Tools (read)** | [Systems accessed read-only] |
| **Tools (read-write)** | [Systems the agent can write to] |

**Human Checkpoints:**

| Moment | Human Action | Reason |
|--------|-------------|--------|
| [When] | [Initiates / Reviews & approves / Overrides / Makes final call] | [Why human is needed here] |

**Evaluation:**

| Completion Signal | [How we know it's done] |
|-------------------|------------------------|
| Failure Scenario 1 | [What fails] → [Fallback] |
| Failure Scenario 2 | [What fails] → [Fallback] |
| Failure Scenario 3 | [What fails] → [Fallback] |

See `references/behavior-design-guide.md` for the full template, design principles, and common agent patterns.

### Step 1 Checkpoint

Present the behavior script and ask:

```
Here's the agent behavior design:

[behavior script]

Does this accurately capture how the agent should behave?

Key things to check:
✓ The autonomy level feels right for user trust
✓ Human checkpoints are placed at the right moments
✓ The failure fallbacks are safe and realistic

- **Looks good** → I'll proceed to create the full PRD
- **Change X** → I'll revise the behavior script first
- **Start over** → I'll redesign from scratch
```

**Do NOT proceed to Step 2 until the user explicitly confirms.** This is a hard pause. The user may need time to review, consult with their team, or think through edge cases. Accept corrections and iterate until they confirm.

---

## Step 2: PRD with Agent Behavior

### Purpose

Take the confirmed behavior script and wrap it in a full PRD structure. The PRD includes everything from the standard PRD template, plus the agent behavior script as a dedicated section and agent-specific use cases and metrics.

### Generate the PRD

Use this prompt structure:

```
Context:
- Confirmed agent behavior script: [from Step 1]
- Selected opportunity: [from Stage 2]
- Product context: [from Stage 0]

Create a concise PRD for this agentic solution.

The PRD must include:
1. Feature name
2. Problem statement (who, what, when, why, current state)
3. Proposed solution (concept, what agent handles vs user controls, scope boundaries)
4. Agent Behavior Script (embed the confirmed script — do not modify)
5. Target segments (primary, secondary, excluded)
6. Use cases (as trigger → agent action → user experience → outcome)
7. Success metrics (include agent-specific: accuracy, utilization, escalation rate, override rate)
8. Dependencies & risks (include agent-specific: trust, incorrect decisions, degradation)

Each assumption in the PRD becomes a testable hypothesis for Stage 6.
```

### PRD Structure (Agentic)

#### 1. Feature Name
Short, descriptive name (2-5 words)

#### 2. Problem Statement
- **Who**: Specific user segment with characteristics
- **Problem**: 1-2 sentences describing the core pain point
- **Context**: When/where this occurs in the user journey
- **Impact**: Why this matters — quantify if possible
- **Current state**: How users handle this today, workarounds

#### 3. Proposed Solution
- **Concept**: 1-2 sentence description including the agentic nature
- **What the agent handles autonomously**: List autonomous capabilities
- **What the user controls**: List user-driven actions
- **Key capabilities**: What the solution provides
- **Out of scope**: Explicitly excluded for this iteration

#### 4. Agent Behavior Script
Embed the confirmed behavior script from Step 1 here. **Copy it exactly as the user confirmed — do not modify.**

#### 5. Target Segments
- **Primary**: Must-serve segment with characteristics
- **Secondary**: Nice-to-serve segment
- **Excluded**: Who this is NOT for and why

#### 6. Use Cases

| # | Trigger | Agent Action | User Experience | Outcome |
|---|---------|-------------|----------------|---------|
| 1 | [What initiates] | [What the agent does] | [What the user sees/does] | [End result] |
| 2 | [What initiates] | [What the agent does] | [What the user sees/does] | [End result] |
| 3 | [What initiates] | [Agent escalates] | [User decides/provides input] | [End result] |
| 4 | [Agent failure] | [Agent fallback] | [User takes manual control] | [End result] |

Include at least one escalation scenario and one failure recovery scenario.

#### 7. Success Metrics

| Metric | Current State | Target | Measurement Method |
|--------|---------------|--------|-------------------|
| [Primary user metric] | [baseline] | [goal] | [how to measure] |
| Agent accuracy | N/A | [target %] | Correct actions / total actions |
| Agent utilization | N/A | [target %] | Completed actions / total triggers |
| Escalation rate | N/A | <[target %] | Escalations / total actions |
| User override rate | N/A | <[target %] | User corrections / total agent actions |
| Time saved per user | [current] | [target reduction] | Before/after analytics |

#### 8. Dependencies & Risks

| Type | Description | Mitigation |
|------|-------------|------------|
| Dependency | [What the agent needs] | [How to handle if unavailable] |
| Risk | Agent makes incorrect decision | Confidence thresholds + user review + undo |
| Risk | User doesn't trust agent | Transparency in reasoning + gradual rollout |
| Assumption | [About agent behavior] | [How to validate in Stage 6] |
| Assumption | [About user acceptance] | [How to validate in Stage 6] |

See `references/agent-prd-template.md` for the full template with examples.

### Step 2 Checkpoint

After outputting the full PRD:

```
Here's the complete PRD with embedded agent behavior:

[PRD]

Please review:
1. Does the problem statement capture the right pain?
2. Is the scope (in/out) correct?
3. Do the use cases cover the key agent scenarios — including escalation and failure?
4. Are the success metrics measurable and realistic?

Approve to continue to Stage 4 (Component Library), or request changes.
```

---

## Writing Guidelines

- **Be concise** — PRD foundation, not full spec
- **Stay high-level** — Avoid pixel-level detail; leave implementation to prototype
- **Include boundaries** — What's out of scope is as important as what's in
- **Agent behavior is the core** — The behavior script is the most important section
- **Use cases should show the agent-user dance** — Not just what the agent does, but what the user experiences
- **Assumptions become experiments** — Every assumption feeds into Stage 6's test plan

---

## Presenting Output

After the user approves the PRD at the Step 2 checkpoint:

1. Write the PRD (with embedded agent behavior script) to the working directory
2. Also save a copy to the user's workspace folder as a markdown file (e.g. `agent-prd-[feature-name].md`)
3. Call `present_files` to show the file to the user as a downloadable card
4. Tell the user: "Here's your agent PRD — download it to share with your team or re-upload in a future session to resume from Stage 4."

---

## Chaining

This skill is designed to work both **standalone** and as part of the Discovery to Prototype Engine.

### Standalone use
Run independently when you have an agentic solution concept and want to design its behavior and produce a PRD. Useful when you already know you're building an agent and want to specify its behavior formally before prototyping.

### As part of the engine
- **Input from**: Stage 2 (Solution Prioritization) — selected opportunity + committed agentic solution concept with autonomy level
- **Output to**: Stage 4 (Component Library) and Stage 5 (Prototype Generator)

Both this skill and the non-agentic path (`discovery-prd-foundation`) converge at Stage 4 — both produce a concise PRD that feeds into component extraction and prototype generation.

To continue: "Build component library" or "Run Stage 4"
