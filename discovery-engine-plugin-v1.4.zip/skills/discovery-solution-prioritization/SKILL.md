---
name: discovery-solution-prioritization
description: "Stage 2 of Discovery to Prototype Engine. Two-phase skill: first scores opportunities on pain intensity, market size, technical feasibility, and strategic alignment; then explores solution concepts for the selected opportunity. Use when user says 'score these opportunities', 'prioritize opportunities', 'run discovery stage 2', or has an opportunity table from Stage 1. Outputs a committed solution concept with agentic/non-agentic flag that drives the PRD branch."
---

# Discovery Solution Prioritization (Stage 2)

Second stage of the Discovery to Prototype Engine. Runs two distinct phases — analytical scoring followed by creative exploration — with a hard checkpoint between them.

**Why two phases:** Scoring is analytical — it's about evidence and weighting. Solution exploration is creative — it's about generating options. Blending them muddies both. The checkpoint between them gives the user a clear "I'm done analyzing, now I'm ready to create" transition. It also prevents wasted ideation effort on an opportunity the user isn't sold on.

## Prerequisites

Requires:
- Top 5 Opportunities from the orchestrator's Stage 1.3 merge step (or equivalent opportunity list with problem description, evidence label, and business impact)
- **Product context** from Stage 0 (collected upfront by the orchestrator). Use this to ground all scoring — interpret pain relative to stated audience, market size relative to target market, feasibility relative to product category, and alignment relative to stated business goals.

If product context is not already available in the conversation, ask the user to provide it before scoring. But in the normal full-workflow path, it should already be present from Stage 0.

---

## Phase 1: Opportunity Scoring

### Purpose

Score each opportunity across four dimensions, rank them, and present a recommendation. The user then selects which opportunity to take forward.

### Scoring Dimensions

See `references/scoring-framework.md` for full criteria, weighting guidance, and calibration examples.

#### 1. User Pain Intensity (1-10)

How much does this problem hurt users daily?

| Score | Meaning |
|-------|---------|
| 9-10 | Excruciating — blocks core job, causes errors with consequences |
| 7-8 | Significant — daily frustration, time wasted, workarounds needed |
| 5-6 | Moderate — noticeable friction, tolerable but annoying |
| 3-4 | Mild — minor inconvenience, users rarely mention it |
| 1-2 | Negligible — edge case, most users unaffected |

#### 2. Market Size (1-10)

How many users/customers are affected?

| Score | Meaning |
|-------|---------|
| 9-10 | Nearly all active users (>80%) |
| 7-8 | Large majority (50-80%) |
| 5-6 | Significant portion (25-50%) |
| 3-4 | Moderate segment (10-25%) |
| 1-2 | Small niche (<10%) |

#### 3. Technical Feasibility (1-10)

How achievable is a solution with current capabilities?

| Score | Meaning |
|-------|---------|
| 9-10 | Straightforward — existing tech, clear path, low risk |
| 7-8 | Achievable — some complexity, known patterns exist |
| 5-6 | Moderate — requires new integrations or meaningful effort |
| 3-4 | Challenging — significant unknowns, dependencies, or R&D |
| 1-2 | Difficult — cutting-edge tech, major infrastructure, high risk |

#### 4. Strategic Alignment (1-10)

How well does this fit company/product direction?

| Score | Meaning |
|-------|---------|
| 9-10 | Core to strategy — directly supports key OKRs/vision |
| 7-8 | Strong fit — aligns with product direction |
| 5-6 | Moderate fit — tangentially related to strategy |
| 3-4 | Weak fit — could distract from priorities |
| 1-2 | Misaligned — conflicts with current direction |

### Confidence Levels

For each score, assign confidence:
- **High**: Strong evidence, clear data, high certainty
- **Medium**: Some evidence, reasonable inference
- **Low**: Limited data, educated guess, needs validation

### Phase 1 Output

Deliver as a scored matrix:

| # | Opportunity | Pain (1-10) | Market (1-10) | Feasibility (1-10) | Alignment (1-10) | Total | Confidence |
|---|-------------|-------------|---------------|-------------------|------------------|-------|------------|
| 1 | [Name] | [Score] | [Score] | [Score] | [Score] | [Sum] | [H/M/L] |

Then for each opportunity, provide a brief reasoning block:

**Opportunity 1: [Name]**
- Pain: [Score] — [reasoning]
- Market: [Score] — [reasoning]
- Feasibility: [Score] — [reasoning]
- Alignment: [Score] — [reasoning]
- Overall confidence: [H/M/L] — [why]

End with a recommendation of the top 1-2 opportunities with rationale.

### Phase 1 Checkpoint

Present the ranked opportunities and ask:

```
Here are the scored opportunities:

[ranked list with scores and reasoning]

Which opportunity would you like to explore further?
- Pick one from the list (e.g. "Let's go with opportunity 2")
- Ask me to rescore with different weights (e.g. "Weight feasibility more heavily")
- Override with a different opportunity not on this list
```

**Do NOT proceed to solution exploration until the user explicitly selects an opportunity.** The user may ask questions, request rescoring, or override the recommendation. Only proceed when they confirm "I want to explore [opportunity X]."

Once the user selects an opportunity, confirm their choice and show:

```
Got it — we're going with: [Opportunity Name]

Moving to Phase 2: Solution Exploration. I'll brainstorm 3–5 ways to solve this problem, including at least one simpler option and one more ambitious one. You'll pick the approach you want to take into the PRD stage.

Type "continue" or just reply and I'll generate the solution concepts now.
```

---

## Phase 2: Solution Exploration

### Purpose

Take the confirmed opportunity as the constraint and brainstorm distinct solution concepts. The user selects one to commit to, and that choice (including its agentic/non-agentic flag) drives the downstream branch.

### Process

See `references/solution-exploration-guide.md` for the concept card template and brainstorming approach.

1. **Restate the opportunity** — Confirm the selected opportunity as the design constraint
2. **Brainstorm 3-5 solution concepts** — Generate distinct approaches to addressing the opportunity
3. **For each concept, produce a concept card:**
   - **Name**: Short, descriptive label
   - **Core idea**: 2-3 sentence description of the approach
   - **Key assumptions**: What must be true for this to work
   - **Agentic or non-agentic**: Flag whether this solution involves AI agent behavior (automated workflows, autonomous decisions, proactive actions) or is a traditional feature/UI improvement
   - **Complexity**: Low / Medium / High
   - **Strongest argument for**: Why pick this one
4. **Present all concepts side by side** for comparison

### Solution Diversity

Aim for meaningful variety across concepts. At least one concept in each set should explore:
- A **simpler, faster-to-build** option (could be an MVP or quick win)
- A **more ambitious, differentiating** option (could be a delighter)
- An **agentic approach** if the opportunity lends itself to automation, proactive behavior, or AI-assisted workflows (not every opportunity will — don't force it)

If the opportunity clearly doesn't suit an agentic approach, note that and only present non-agentic concepts.

### Agentic vs. Non-Agentic Classification

Flag each concept clearly:

| Type | Characteristics | Examples |
|------|----------------|----------|
| **Non-agentic** | Traditional feature, UI improvement, workflow enhancement, tool that user operates | Dashboard, filter, report builder, onboarding wizard, form redesign |
| **Agentic** | AI agent, automated workflow, autonomous behavior, proactive system that acts on behalf of the user | Auto-categorization agent, proactive alert system, AI assistant that drafts responses, auto-reconciliation that runs without user initiation |

Use the five-level autonomy framework as a reference:
- **Chatbot** → Non-agentic (responds only when asked)
- **Copilot** → Non-agentic (assists user in real-time, user drives)
- **Assistant** → Borderline (can take simple autonomous actions within guardrails)
- **Agent** → Agentic (acts autonomously on triggers, makes decisions within boundaries)
- **Non-agentic** → Traditional feature with no AI autonomy

### Phase 2 Checkpoint

Present the solution concepts and ask:

```
Here are the solution concepts for [opportunity]:

[concept cards with descriptions, assumptions, and agentic flags]

Which solution should we commit to and take into the PRD stage?
- Reply with the concept name or number (e.g. "Go with concept 2")
- Ask for more detail on any concept before deciding
- Request a different concept if none of these feel right
```

**Do NOT proceed until the user explicitly commits to a solution.** The user may ask for more detail on a concept, request modifications, or ask for additional concepts. Only proceed when they confirm their choice.

Once the user commits, show this handoff message:

```
Stage 2 complete! Solution committed: [Solution Name]

---

**Next step → Stage 3: Write the PRD**

Based on your solution choice, I'll create a Product Requirements Document that defines the problem, solution, user flows, and success metrics.

Type: "Create the PRD" or "Run Stage 3"
→ No additional inputs needed — I'll use the solution you just committed to.

(If you chose an agentic solution, I'll use the Agent PRD format. If non-agentic, I'll use the standard PRD format.)
```

---

## Final Output

The skill's output is the combination of both phases:

1. **Selected opportunity** — the opportunity the user chose from the scored matrix
2. **Committed solution concept** — the concept card the user committed to, including:
   - Name, core idea, key assumptions
   - **Agentic/non-agentic flag** — this drives the orchestrator's branch decision

The orchestrator reads the flag and routes:
- Non-agentic → `discovery-prd-foundation` (Stage 3.1)
- Agentic → `discovery-agent-prd` (Stage 3.2+3.3)

---

## Presenting Output

After the user commits to a solution at the Phase 2 checkpoint:

1. Write the output to the working directory as already specified (`stage-2-selected-opportunity.md`)
2. Also save a copy to the user's workspace folder
3. Call `present_files` to show the file to the user as a downloadable card
4. Tell the user: "Here's your selected opportunity and solution concept — download it to share with your team or re-upload in a future session to resume from Stage 3."

---

## Chaining

This skill is designed to work both **standalone** and as part of the Discovery to Prototype Engine.

### Standalone use
Run independently when you have a set of opportunities and want to score, select, and explore solutions. Useful for prioritization sessions or when you already have opportunities from another source.

### As part of the engine
- **Receives input from**: Orchestrator's internal Stage 1.3 step (Top 5 Opportunities with evidence labels)
- **Output feeds into**: Orchestrator reads the agentic flag and routes to Stage 3.1 (`discovery-prd-foundation`) or Stage 3.2+3.3 (`discovery-agent-prd`)

### Handoff format
The orchestrator expects from this skill:
- Selected opportunity name and description
- Committed solution concept card (name, core idea, key assumptions, complexity)
- Agentic/non-agentic flag (explicit)

To continue: "Create a PRD for this solution" or "Run Stage 3"
