# Solution Exploration Guide

How to brainstorm solution concepts and structure concept cards for Phase 2 of Solution Prioritization (Stage 2).

---

## Brainstorming Approach

Once the user has selected an opportunity, shift from analytical mode to creative mode. The goal is to generate 3-5 meaningfully different approaches to the same problem — not variations on one theme.

### Generating Diverse Concepts

Start by framing the opportunity as a design constraint:

```
The opportunity: [restate the selected opportunity]
The user pain: [core pain point from scoring]
The target segment: [who experiences this]
The strategic context: [relevant business goals]

Given these constraints, what are fundamentally different ways to solve this?
```

Then explore across these dimensions:

| Dimension | What to vary |
|-----------|-------------|
| **Scope** | Minimal viable fix vs. comprehensive solution vs. platform-level change |
| **Automation level** | Manual tool vs. assisted workflow vs. fully autonomous agent |
| **User interaction model** | Self-serve vs. guided vs. proactive (system initiates) |
| **Technical approach** | UI-first vs. data-first vs. AI-first |
| **Time horizon** | Quick win (weeks) vs. medium build (months) vs. strategic investment (quarters) |

### Diversity Checklist

Before presenting concepts, verify:
- [ ] At least one concept is simpler/faster to build than the others
- [ ] At least one concept is more ambitious/differentiating
- [ ] At least one concept explores an agentic approach (if the opportunity suits it)
- [ ] No two concepts are just "the same idea at different scales"
- [ ] Each concept has a distinct core mechanism (not just different UI for the same logic)

If the opportunity clearly doesn't suit an agentic approach, note that explicitly and present only non-agentic concepts. Don't force agentic solutions where they don't fit.

---

## Concept Card Template

For each solution concept, produce:

```
### Concept [N]: [Name]

**Core idea:** [2-3 sentences describing the approach — what it does, how it works, what the user experiences]

**Key assumptions:**
- [Assumption 1 — what must be true for this to work]
- [Assumption 2]
- [Assumption 3]

**Type:** [Non-agentic / Agentic]
**Complexity:** [Low / Medium / High]

**Strongest argument for:** [1-2 sentences — why would you pick this one over the others?]
```

### Field Guidance

**Core idea:** Describe the solution from the user's perspective first (what changes for them), then explain the mechanism (how it works under the hood). Keep it concrete — avoid vague "AI-powered" descriptions without explaining what the AI actually does.

**Key assumptions:** List 2-4 things that must be true for this concept to succeed. These become testable hypotheses in Stage 6 (Experiment Plan). Good assumptions are specific and falsifiable:
- ✅ "Users will trust auto-categorized transactions if accuracy exceeds 95%"
- ❌ "Users will like this feature"

**Type (Agentic / Non-agentic):** Use the five-level autonomy framework:

| Level | Classification | Description |
|-------|---------------|-------------|
| Chatbot | Non-agentic | Responds only when asked; no autonomous action |
| Copilot | Non-agentic | Assists user in real-time; user drives every step |
| Assistant | Borderline — classify as agentic | Takes simple autonomous actions within guardrails |
| Agent | Agentic | Acts autonomously on triggers; makes decisions within boundaries |
| Traditional feature | Non-agentic | No AI component; standard UI/workflow |

When in doubt between Assistant and Copilot, ask: "Does this system ever take action without the user explicitly telling it to?" If yes → agentic.

**Complexity:** Rough sizing to help the user calibrate expectations:
- **Low**: Weeks of work, known patterns, minimal unknowns
- **Medium**: 1-2 months, some new integrations or workflows, moderate unknowns
- **High**: Quarter+, significant new infrastructure or R&D, many unknowns

**Strongest argument for:** Why would a reasonable PM pick this concept? This helps the user compare concepts on their differentiating merit, not just on a feature list.

---

## Presentation Format

Present all concepts together for side-by-side comparison. After the concept cards, add a brief comparison summary:

```
## Comparison

| Concept | Type | Complexity | Best if... |
|---------|------|-----------|------------|
| [Name 1] | Non-agentic | Low | You want a quick, low-risk win |
| [Name 2] | Non-agentic | Medium | You want a solid feature that covers the core pain |
| [Name 3] | Agentic | High | You want to differentiate with automation |
```

Then prompt the user to commit:

```
Which solution should we commit to and take into the PRD stage?
- The branch to agentic (Agent PRD) or non-agentic (PRD Foundation) depends on your choice.
```

---

## Edge Cases

- **User wants to combine concepts:** Allow it, but ask them to define which elements from which concepts. Create a hybrid concept card for confirmation.
- **User wants more concepts:** Generate 2-3 more, exploring dimensions not yet covered.
- **User isn't ready to commit:** That's fine — they can pause here and return. Note the concepts in the conversation for resumption.
- **All concepts are non-agentic:** This is valid. Not every opportunity suits an agentic approach. Note it and proceed.
- **User picks an agentic concept but is uncertain about the agentic parts:** Suggest starting with Stage 3.2+3.3 (Agent PRD) which will design the agent behavior first and let them review before committing it to a full PRD.
