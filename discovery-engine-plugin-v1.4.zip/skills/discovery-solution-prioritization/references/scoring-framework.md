# Scoring Framework Reference

Scoring criteria, weighting guidance, and calibration examples for Phase 1 of Solution Prioritization (Stage 2).

---

## Scoring Dimensions

### 1. User Pain Intensity (1-10)

**What it measures:** How severely the problem affects users in their daily work.

**How to score using product context:**
- Score relative to the stated target audience's pain points (from Stage 0)
- Reference severity scores from Stage 1.1 customer data when available
- Consider frequency (daily vs. occasional) and impact (blocking vs. inconvenient)

**Calibration examples:**
| Score | Example |
|-------|---------|
| 10 | Users cannot complete their core job without a manual workaround; active churn driver |
| 8 | Daily friction that wastes 30+ minutes and causes regular errors |
| 6 | Noticeable pain that users mention in feedback but tolerate |
| 4 | Minor annoyance that surfaces occasionally |
| 2 | Edge case affecting few users in rare situations |

---

### 2. Market Size (1-10)

**What it measures:** What proportion of the target audience is affected by this problem.

**How to score using product context:**
- Score relative to the defined target audience (from Stage 0), not the entire market
- Reference user segment data from Stage 1.1 when available
- Consider both breadth (how many users) and depth (how often they encounter it)

**Calibration examples:**
| Score | Example |
|-------|---------|
| 10 | Affects virtually every active user, every day |
| 8 | Affects the majority (60-80%) of active users regularly |
| 6 | Affects a significant segment (30-50%), or many users occasionally |
| 4 | Affects a specific sub-segment (10-25%) |
| 2 | Affects a small niche (<10%) in specific situations |

---

### 3. Technical Feasibility (1-10)

**What it measures:** How achievable a solution is given current technology, team capabilities, and product architecture.

**How to score using product context:**
- Score relative to the product category and likely tech stack (from Stage 0)
- Consider whether similar solutions exist in the market (from Stage 1.2 competitive data)
- Higher scores = less risk, lower effort, known patterns

**Calibration examples:**
| Score | Example |
|-------|---------|
| 10 | Configuration change or minor UI update; no backend work |
| 8 | Standard feature with known implementation patterns; weeks of work |
| 6 | Requires new integrations or moderate backend changes; 1-2 months |
| 4 | Significant unknowns, new infrastructure, or R&D needed; quarter+ |
| 2 | Cutting-edge technology, fundamental architecture changes, high risk |

---

### 4. Strategic Alignment (1-10)

**What it measures:** How well the opportunity fits with the company's stated direction and goals.

**How to score using product context:**
- Score directly against the stated business goals (from Stage 0)
- An opportunity that directly supports a top-2 goal gets 8+
- An opportunity tangentially related scores 5-6
- An opportunity that would distract from stated priorities scores 3-4

**Calibration examples:**
| Score | Example |
|-------|---------|
| 10 | Directly supports the #1 business goal; CEO would champion it |
| 8 | Strongly aligns with product strategy; fits current roadmap themes |
| 6 | Related to strategy but not a direct lever; could fit into a future cycle |
| 4 | Tangential; would require deprioritizing something more strategic |
| 2 | Actively conflicts with current direction or stated priorities |

---

## Weighting

Default weighting is equal (each dimension worth 25% of total). However, the user may request different weights based on their context:

| Scenario | Suggested Weight Adjustment |
|----------|-----------------------------|
| "We need quick wins" | Increase Feasibility weight |
| "Growth is the priority" | Increase Market Size weight |
| "Users are churning" | Increase Pain Intensity weight |
| "We need to stay on strategy" | Increase Strategic Alignment weight |

If the user asks for custom weights, apply them transparently and show both the unweighted and weighted totals.

---

## Confidence Levels

| Level | Criteria | Action |
|-------|----------|--------|
| **High** | Score backed by specific data points (e.g., "34% of detractors cited this"), clear evidence from Stage 1, or well-established market knowledge | Report as-is |
| **Medium** | Score based on reasonable inference from available data, partial evidence, or competitive analogy | Note what additional data would increase confidence |
| **Low** | Score is an educated guess based on limited data, general assumptions, or single-source evidence | Flag prominently; recommend validation before committing |

When the overall confidence for an opportunity is Low, explicitly recommend that the user validate the key assumptions before selecting it.
