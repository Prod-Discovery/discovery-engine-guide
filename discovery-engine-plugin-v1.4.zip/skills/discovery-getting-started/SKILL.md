---
name: discovery-getting-started
description: "Quick-start orientation for the Discovery to Prototype Engine plugin. Use when user says 'getting started', 'what is this plugin', 'how do I use this', 'what can this do', 'help me get started', 'what does this engine do', 'where do I start', or seems unsure what to do after installing the plugin. Also triggers on 'help', 'what skills do I have', or 'what's installed'. This is the first skill new users should encounter — it explains the engine, shows what's possible, and hands them the exact phrase to begin."
---

# Getting Started with the Discovery to Prototype Engine

You've just installed a workflow engine that takes you from raw customer feedback to a testable interactive prototype — in hours instead of weeks. This guide helps you understand what you have and how to start using it.

## What This Engine Does

The Discovery to Prototype Engine is a 6-stage workflow for product managers and designers. You feed it customer data and product context, and it guides you through:

1. **Understanding your landscape** — analyzing customer pain points and competitor gaps
2. **Picking the right opportunity** — scoring and prioritizing what to build
3. **Defining what to build** — writing a product requirements document
4. **Building a realistic prototype** — extracting your product's visual design and generating an interactive React prototype
5. **Planning how to test it** — creating an experiment plan and usability test script

Each stage has a checkpoint where you review the output and decide whether to continue, adjust, or stop. You're always in control.

## How to Start

**Option A — Run the full workflow from the beginning:**

Say this:

> "Run the full discovery to prototype workflow"

The engine will guide you step by step. It starts by asking about your product, then walks you through each stage. You don't need to have everything ready — it tells you what it needs at each step.

**Option B — Jump to a specific stage:**

If you already have some outputs (e.g., you have a PRD and just want a prototype), say:

> "Jump to Stage 5" or "I already have a PRD, generate a prototype"

The engine will ask you for whatever that stage needs as input.

## Slash Commands — Your Shortcut Menu

Any time you want to run a stage or action, type **`/`** (forward slash) in the chat. A dropdown menu will appear listing all available skills from the engine. Select one and it runs immediately — no need to remember exact phrases.

This is especially useful when you want to:
- **Repeat a stage** you've already run (e.g., re-run competitive analysis with new competitors)
- **Run a single stage** without starting the full workflow
- **See everything that's available** — the slash menu shows all installed skills at a glance

Think of it as the engine's command palette. The full workflow and quick commands below still work — slash commands are just a faster way to get to the same things.

## What You'll Need

You don't need all of this upfront — the engine asks for what it needs at each stage:

| What | When | Examples |
|------|------|---------|
| Product context | Stage 0 (first thing) | A strategy doc, pitch deck, or just answers to a few questions about your product |
| Customer data | Stage 1 | CSV exports of NPS scores, support tickets, customer feedback |
| Competitor names | Stage 1 | 2–4 competitor names — the engine researches them using public sources |
| Component library or design system | Stage 4 | If your team has an existing component library repo, clone it locally and run in Claude Code for the best results. If not, Stage 4 will offer other options — Figma connection, design system files, product screenshots, or building from scratch. |

## The Stages at a Glance

```
SENSE — Understand the landscape
  Stage 0    Set up product context
  Stage 1.1  Analyze customer data
  Stage 1.2  Research competitors
  Stage 1.3  Merge into Top 5 Opportunities (automatic)
  Stage 2    Score, pick an opportunity, and commit to a solution direction

SHAPE — Build the response
  Stage 3    Write the PRD (product requirements)
  Stage 4    Build or connect your component library
  Stage 5    Generate an interactive React prototype
  Stage 6    Create an experiment plan and usability test script
```

## Quick Commands

| Say this... | To do this... |
|-------------|---------------|
| "Run the full discovery to prototype workflow" | Start from the beginning |
| "Jump to Stage [N]" | Start at a specific stage |
| "Analyze this customer data" | Run Stage 1.1 only |
| "Research competitors" | Run Stage 1.2 only |
| "Score these opportunities" | Run Stage 2 only |
| "Create a PRD for [opportunity]" | Run Stage 3 only |
| "Build component library" or "Connect my design system" | Run Stage 4 only |
| "Generate prototype" | Run Stage 5 only |
| "Create test plan" | Run Stage 6 only |

## Tips for Your First Run

- **Start with "Run the full discovery to prototype workflow"** — even if you don't finish all 6 stages, the engine saves outputs at every stage so you can pick up later.
- **Upload a strategy doc or pitch deck early** — this is the fastest way to give the engine product context. It extracts what it needs and asks about gaps.
- **Take checkpoints seriously** — corrections in Stage 1 save hours of rework in Stages 4–6.
- **You can stop at any stage** — say "stop here" and your progress is saved.

## Ready?

Say **"Run the full discovery to prototype workflow"** to begin, or ask me anything about how a specific stage works.
