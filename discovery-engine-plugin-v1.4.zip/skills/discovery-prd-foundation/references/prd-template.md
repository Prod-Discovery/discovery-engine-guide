# PRD Template

## [Feature Name]

### Problem Statement

**Who**: [Specific user segment with characteristics]

**Problem**: [1-2 sentences describing the core pain point]

**Context**: [When/where this problem occurs in the user journey]

**Impact**: [Why this matters — quantify if possible]

**Current state**: [How users handle this today, workarounds]

---

### Proposed Solution

**Concept**: [1-2 sentence description of the solution approach]

**Key capabilities**:
- [Capability 1]
- [Capability 2]
- [Capability 3]

**Out of scope** (for this iteration):
- [Explicitly excluded feature/capability]
- [Another excluded item]

---

### Target Segments

**Primary**: [Must-serve segment]
- Characteristics: [qualifying traits]
- Size: [estimate if known]

**Secondary**: [Nice-to-serve segment]
- Characteristics: [qualifying traits]

**Excluded**: [Who this is NOT for]
- [Excluded segment and why]

---

### Use Cases

| # | As a... | I want to... | So that... |
|---|---------|--------------|------------|
| 1 | small business owner processing invoices | scan a paper invoice with my phone | I don't have to manually type every field |
| 2 | bookkeeper entering supplier bills | review and correct OCR-extracted data | I can trust the numbers before saving |
| 3 | accountant reconciling monthly expenses | batch-process multiple invoices | I can complete month-end faster |
| 4 | finance manager reviewing entries | see which invoices were auto-extracted vs manual | I can audit data quality |
| 5 | new user trying the feature | get guided through my first scan | I understand how it works without training |

---

### Success Metrics

| Metric | Current | Target | How to Measure |
|--------|---------|--------|----------------|
| Avg time to enter invoice | 4.2 min | <1 min | Analytics: time from start to save |
| Data entry errors | 12% of invoices | <3% | Support tickets + user corrections |
| Feature adoption | N/A | 60% of invoice users in 90 days | % users who scan at least 1 invoice |
| User satisfaction (feature NPS) | N/A | >40 | In-app survey after 5th use |

---

### Dependencies & Risks

| Type | Description | Mitigation |
|------|-------------|------------|
| Dependency | OCR service API (vendor selection) | Evaluate 3 vendors in spike before prototype |
| Dependency | Camera access on mobile | Graceful fallback to file upload |
| Risk | OCR accuracy on poor-quality images | Set user expectations, manual correction flow |
| Risk | Processing time may frustrate users | Async processing with progress indicator |
| Assumption | Users will trust auto-extracted data | Validate with prototype testing |
| Assumption | Phone camera quality is sufficient | Test with representative device sample |

---

## Example Completed PRD

### Invoice OCR Scanner

**Problem Statement**

**Who**: Small business owners and bookkeepers processing 20+ invoices per month

**Problem**: Manual invoice data entry is slow, error-prone, and tedious — users spend an average of 4.2 minutes per invoice typing fields that could be automatically extracted.

**Context**: Occurs daily during accounts payable workflow, especially painful at month-end when volume spikes.

**Impact**: 34% of NPS detractors cite data entry frustration; 180 support tickets/month relate to entry errors. Estimated 8+ hours/month wasted per active user.

**Current state**: Users either type everything manually, or copy-paste from PDF viewers — both approaches are slow and introduce errors.

---

**Proposed Solution**

**Concept**: Mobile-first invoice scanner that uses OCR to automatically extract and populate invoice fields, with a review step before saving.

**Key capabilities**:
- Capture invoice via phone camera or file upload
- Extract key fields: vendor, date, amount, line items, invoice number
- Present extracted data for user review and correction
- Save to accounting system with audit trail

**Out of scope**:
- Automatic approval workflows
- Multi-page document handling (v1 = single page)
- Integration with external AP systems
