---
name: discovery-prototype-generator
description: "Stage 5 of Discovery to Prototype Engine. Generates an interactive React prototype based on PRD and component library. Use when user says 'generate prototype', 'build the prototype', 'create interactive mockup', 'run discovery stage 5', or has PRD and component library ready. Outputs functional prototype demonstrating key user flows."
---

# Discovery Prototype Generator (Stage 5)

Fifth stage of the Discovery to Prototype Engine. Builds a functional, interactive prototype that demonstrates the proposed solution.

## Prerequisites

Requires outputs from previous stages:
- **PRD Foundation** (Stage 3) — Problem, solution, use cases
- **Component Library** (Stage 4) — Reusable React components

Can proceed without component library (will use Tailwind defaults) but visual fidelity will be lower.

## Workflow

1. **Load context** — Import PRD and component library
2. **Plan screens** — Map use cases to screens/views
3. **Build structure** — Create page layout and navigation
4. **Implement flows** — Add interactivity for key scenarios
5. **Add sample data** — Populate with realistic content
6. **Output prototype** — Deliver as React artifact, checkpoint for review

## Prototype Scope

Based on PRD use cases, prototype should include:

### Screens (typically 3-6)
- One screen per major user flow step
- Cover the "happy path" completely
- Include key decision points

### Interactivity
- Clickable navigation between screens
- Form inputs that update state
- Buttons that trigger visible changes
- Feedback on actions (loading, success, error states)

### Sample Data
- Realistic (not "lorem ipsum")
- Sufficient variety to show different states
- Edge cases if relevant (empty states, errors)

## Technical Approach

### React Structure

```jsx
// Main App structure
function App() {
  const [currentView, setCurrentView] = useState('home');
  const [data, setData] = useState(initialData);
  
  return (
    <div className="app">
      <Header />
      {currentView === 'home' && <HomeView />}
      {currentView === 'detail' && <DetailView />}
      {currentView === 'success' && <SuccessView />}
    </div>
  );
}
```

### Using Component Library

If component library exists, import and use:
```jsx
import { Button, Card, Input, Table } from './component-library';
```

If no component library, use Tailwind utility classes.

### State Management

- Use React useState for simple state
- Keep state at appropriate level (lift when needed)
- Mock API calls with setTimeout for realism

## Output Requirements

### Must Have
- All primary use case flows navigable
- Core interaction working (forms submit, data displays)
- Visual consistency with product (if components available)
- Responsive basics (works on desktop viewport)

### Nice to Have
- Secondary flows
- Error states
- Loading states
- Mobile responsiveness

### Explicitly Excluded
- Backend integration
- Authentication
- Data persistence
- Production-ready code

## Iteration Support

Prototype should be structured for easy iteration:
- Clear component separation
- Commented sections for each flow
- Easy to swap/modify individual screens

Common iteration requests:
- "Add another screen for X"
- "Change the flow when user clicks Y"
- "Update the copy/content"
- "Adjust the layout of Z section"

## Checkpoint Behavior

After generating the prototype:
1. Present the prototype artifact (runnable in chat)
2. Walk through each use case flow
3. Ask for feedback on:
   - Missing functionality
   - UX improvements
   - Visual adjustments
4. Iterate based on feedback
5. Confirm prototype is ready for testing

Once the user is happy with the prototype, show this handoff message:

```
Stage 5 complete! Prototype approved.

---

**Next step → Stage 6: Create the Experiment Plan**

This is the final stage. I'll produce everything you need to test the prototype with real users:
- A list of critical assumptions ranked by risk
- A testable hypothesis
- A recommended test method (usually a usability test)
- Clear success criteria
- A full facilitator script you can use to run the sessions

Type: "Create the experiment plan" or "Run Stage 6"
→ No additional inputs needed — I'll use the PRD and prototype from the previous stages.
```

## Lovable Export (if connected)

After the prototype is approved, check whether Lovable is connected.

**If Lovable is connected:**

```
Your prototype is ready. I also see you have Lovable connected.

Would you like me to export the component library and PRD to Lovable so you can refine, iterate, and deploy the prototype there?

1. Export to Lovable — I'll push the artifacts now
2. Keep it here — copy the React code manually to any tool you want

Either way, the prototype code is available in this conversation.
```

If the user chooses to export:
- Push the component library files and PRD to Lovable
- Confirm the export completed and provide a link or next steps in Lovable
- Note that the locally generated prototype still serves as the reference

**If Lovable is not connected:**

Do not mention Lovable. Simply confirm the prototype is available and bridge to Stage 6.

## Presenting Output

After the user confirms the prototype at the checkpoint:

1. Save the prototype file (.html or .jsx) to the user's workspace folder
2. Call `present_files` to show the file to the user
3. Tell the user: "Here's your prototype — open it in a browser to interact with it, or share with your team for review."

## Chaining

- **Input from**: Stage 3 (PRD) + Stage 4 (Component Library)
- **Output to**: Stage 6 (Experiment Plan)

To continue: "Create test plan" or "Run Stage 6"
