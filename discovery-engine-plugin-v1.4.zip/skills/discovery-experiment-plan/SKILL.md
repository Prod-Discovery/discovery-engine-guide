---
name: discovery-experiment-plan
description: "Stage 6 of Discovery to Prototype Engine. Creates an experiment plan and usability test script for validating the prototype. Use when user says 'create test plan', 'prepare usability test', 'write experiment plan', 'run discovery stage 6', or has a prototype ready to test. Outputs assumptions, hypothesis, test method, success criteria, and interview script."
---

# Discovery Experiment Plan (Stage 6)

Final stage of the Discovery to Prototype Engine. Prepares everything needed to validate the prototype with real users.

## Prerequisites

Requires context from previous stages:
- **PRD Foundation** (Stage 3) — Problem, use cases, success metrics
- **Prototype** (Stage 5) — Interactive artifact to test

## Workflow

1. **Extract assumptions** — Identify what must be true for this to succeed
2. **Prioritize by risk** — Rank assumptions by consequence if wrong
3. **Form hypothesis** — Create testable statement for riskiest assumption
4. **Design test** — Choose smallest test that validates/invalidates
5. **Define success** — Set measurable criteria
6. **Write test script** — Create facilitator guide with tasks
7. **Output plan** — Deliver experiment plan + test script

## Experiment Plan Structure

### 1. Critical Assumptions

Categorize assumptions across four dimensions:

| Dimension | Question | Example Assumptions |
|-----------|----------|-------------------|
| **Desirability** | Do users want this? | Users will prefer scanning over typing |
| **Feasibility** | Can we build this? | OCR accuracy will exceed 90% |
| **Viability** | Does the business work? | Time saved justifies development cost |
| **Trust** | Will users trust it? | Users will accept AI-extracted data |

For each assumption:
- State it clearly
- Rate risk: High/Medium/Low
- Note what evidence exists (or doesn't)

### 2. Hypothesis

Turn the riskiest assumption into a testable hypothesis:

**Format**: "We believe [assumption]. We will know this is true when [measurable signal]."

**Example**: "We believe users will prefer scanning invoices over manual entry. We will know this is true when 70%+ of test participants complete the scan task faster and report higher satisfaction."

### 3. Test Method

Choose the smallest test that answers the question:

| Method | Best For | Effort |
|--------|----------|--------|
| Usability test | Interaction, comprehension, task completion | Medium |
| Fake door test | Demand signal, intent to use | Low |
| Wizard of Oz | Complex backend not yet built | Medium |
| Concierge | Service design, high-touch flows | High |
| A/B test | Comparing variants (needs traffic) | High |

For prototype testing, **usability test** is typically appropriate.

### 4. Success Criteria

Define measurable signals:

| Signal | Threshold | Measurement |
|--------|-----------|-------------|
| Task completion rate | >80% | % who complete without help |
| Time on task | <2 minutes | Stopwatch from start to end |
| Satisfaction | >4/5 | Post-task rating |
| Intent to use | >70% "definitely/probably" | Post-test survey |

### 5. Next Steps

Plan for both outcomes:

**If validated**:
- What's the next stage? (Development, wider test, etc.)
- What questions remain?

**If invalidated**:
- What do we learn?
- Pivot, iterate, or kill?

## Usability Test Script

### Test Script Structure

See references/test-script-template.md for full template.

**Sections**:
1. Introduction (2 min) — Welcome, set expectations, consent
2. Background questions (3 min) — Understand participant context
3. Tasks (15-20 min) — Scenario-based tasks with prototype
4. Post-task questions — After each task, quick reaction
5. Debrief (5 min) — Overall impressions, comparison, closing

### Task Design Principles

- **Scenario-based**: Give context, not just instructions
- **Goal-oriented**: State what to achieve, not how
- **Realistic**: Use believable situations
- **Observable**: Tasks should produce visible behavior

**Good task**: "Imagine you just received this invoice from your supplier. You want to add it to your accounting records. Please show me how you would do that."

**Bad task**: "Click the scan button and upload an invoice."

## Checkpoint Behavior

After outputting experiment plan and test script:
1. Review assumptions — are the riskiest identified?
2. Validate hypothesis is testable
3. Confirm success criteria are measurable
4. Walk through test script
5. Finalize for user to run sessions

Once the user confirms everything looks good, check whether Google Drive is connected. If it is, confirm all outputs have been saved to the shared Drive folder.

Then show this completion message:

```
Stage 6 complete! You've finished the full Discovery to Prototype Engine.

---

Here's what you've produced in this run:

  Stage 0  Product context
  Stage 1  Customer insights + competitive landscape + Top 5 Opportunities
  Stage 2  Scored opportunity + committed solution concept
  Stage 3  PRD
  Stage 4  Component library
  Stage 5  Interactive React prototype
  Stage 6  Experiment plan + usability test script

[If Google Drive is connected: All outputs have been saved to your shared Drive folder. Your team can access everything there.]
[If Google Drive is not connected: All outputs are available in this conversation. Download them from Cowork to share with your team.]

**You're now ready to:**
- Recruit 5–8 participants matching your target user profile
- Run usability sessions using the test script from Stage 6
- Observe, note patterns, and decide: build it, iterate, or kill it

**If you want to iterate based on test results:**
  Type: "Update the PRD with new findings" → revise Stage 3, then re-run Stages 5–6
  Type: "Explore a different solution" → go back to Stage 2 and pick a different concept
  Type: "Start a new discovery run" → restart from Stage 0 with a new product or opportunity

Good luck with the testing!
```

## Outputs

This stage produces two deliverables:
1. **Experiment Plan** (Markdown) — Assumptions, hypothesis, method, criteria
2. **Test Script** (Markdown) — Facilitator guide ready to use

## Presenting Output

After the user finalises the experiment plan and test script:

1. Save both the experiment plan and the test script as separate markdown files to the user's workspace folder (e.g. `experiment-plan.md` and `usability-test-script.md`)
2. Call `present_files` on both files to show them as downloadable cards
3. Tell the user: "Here are your experiment plan and test script — download them to share with your team. You're ready to recruit participants and run sessions!"

## End of Workflow

Stage 6 completes the Discovery to Prototype Engine. User is now ready to:
- Recruit participants
- Conduct usability sessions
- Analyze results
- Decide next steps based on findings
