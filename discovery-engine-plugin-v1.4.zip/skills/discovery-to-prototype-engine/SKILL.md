---
name: discovery-to-prototype-engine
description: "Stage 0: Workflow Orchestration + full engine orchestrator. Ingests product context, determines workflow path, and orchestrates all downstream stages. Use when user says 'run discovery to prototype', 'full discovery workflow', 'end to end product discovery', or wants to go from raw customer feedback to a validated prototype. First runs Stage 0 (context ingestion), then orchestrates Stage 1 through Stage 6 with checkpoints at every stage."
---

# Discovery to Prototype Engine

Complete workflow that transforms scattered customer data into a testable prototype with experiment plan. Begins with Stage 0 (Workflow Orchestration) to ingest product context, then orchestrates all downstream stages with checkpoints.

## Overview

This is the master orchestrator for a checkpoint-based workflow that transforms customer data and competitive intelligence into a testable prototype. It operates across two phases — **Sense** (understand the landscape) and **Shape** (build the response):

```
SENSE PHASE
[Stage 0: Context] → [Stage 1.1 + 1.2: Insights] → [Stage 1.3: Merge] → [Stage 2a: Score] → [Stage 2b: Explore]
   Orchestration      Parallel or sequential          Internal step        User selects opp.   User commits solution
                                                                                                  ↓ agentic flag

SHAPE PHASE
[Stage 3: PRD] → [Stage 4: Components] → [Stage 5: Prototype] → [Stage 6: Test Plan]
 3.1 or Agent PRD     Extract library         Generate              Plan + Script
```

## State Management: Output Files

Every stage writes its structured output to a file in the working folder before completing. This serves two purposes:
- **In Cowork**: The file is the handoff mechanism. When a subagent completes, its context window disappears — only the file survives. The orchestrator reads the file and passes it to the next subagent.
- **In Claude.ai chat**: The file provides a clean, condensed reference point. The orchestrator reads the file at each stage transition instead of parsing back through conversation history. This keeps attention on the confirmed output, not the exploration that produced it.

### File Convention

All stage output files are written to `/home/claude/discovery-engine/`:

| Stage | File | Contents |
|-------|------|----------|
| 0 | `product-context.md` | Confirmed product context (name, audience, market, goals, competitors) |
| 1.1 | `stage-1-1-customer-insights.md` | Opportunity table with pain points, severity scores, segments, business impact |
| 1.2 | `stage-1-2-competitive-landscape.md` | Comparison table + competitive gap summary with signal strengths |
| 1.3 | `stage-1-3-top-5-opportunities.md` | Ranked Top 5 Opportunities with evidence labels and detailed rationale |
| 2 | `stage-2-selected-opportunity.md` | Scored matrix, selected opportunity, committed solution concept, agentic/non-agentic flag |

Stages 3–6 already write their primary artifacts to disk (PRD, component library, prototype, test plan). These output files supplement that pattern for the Sense phase stages that previously relied on conversation context alone.

### Google Drive Integration

At startup (Stage 0), check whether Google Drive is connected.

**If Google Drive is connected:**
- At each stage transition, write stage output files to both `/home/claude/discovery-engine/` (local) and the user's shared Drive folder
- When a stage needs input files (CSVs, screenshots, prior stage outputs), check the Drive folder first before asking the user to upload manually
- This enables team handoffs: one person can run the Sense phase, save to Drive, and another person can run the Shape phase by reading from the same Drive folder

**If Google Drive is not connected:**
- Write output files to `/home/claude/discovery-engine/` only
- Ask the user to upload files manually at each stage that needs them

### Reading Files at Stage Transitions

At each stage transition, the orchestrator reads the relevant output files using `view` and uses **only the file contents** as input for the next stage. Do not reference earlier conversation history for stage inputs — the files are the canonical source.

---

## Environment-Aware Behavior

This orchestrator adapts its execution strategy based on the runtime environment:

- **Cowork (with subagents)**: Spawn Stages 1.1 and 1.2 as parallel subagents. Each subagent receives the confirmed product context and its specific inputs. The orchestrator waits for both to complete, then runs the 1.3 merge internally.
- **Claude.ai (no subagents)**: Run Stages 1.1 and 1.2 sequentially in conversation. All prior outputs remain available in chat history. After both complete, run the 1.3 merge internally.

Detect by checking for subagent availability. If subagents are not available, fall back to sequential execution.

### Cowork Parallel Execution Pattern

```
Orchestrator spawns:
  → Subagent A: Run discovery-customer-insights with [data files] and [product context]
  → Subagent B: Run discovery-competitive-landscape with [competitor names] and [product context]

Orchestrator waits for both to complete.

Orchestrator runs Stage 1.3 merge internally (not delegated to a skill).

Orchestrator routes merged Top 5 Opportunities to Stage 2.
```

When spawning subagents, pass the full confirmed product context to each. Subagents don't share memory — each gets everything it needs in the task prompt.

---

## Stage 0: Context Ingestion

### Purpose

Stage 0 collects and confirms product context before any analysis begins. This context grounds every downstream stage — from customer data synthesis to competitive research to scoring to PRD creation.

### Input

The user provides context in any combination of:
- **Uploading documents**: Product strategy decks, one-pagers, market research, investor pitch decks, internal wikis, competitive analyses, board presentations — any document that describes the product, market, audience, or strategy. Upload as PDF, DOCX, PPTX, or plain text.
- **Answering questions directly**: For anything the documents don't cover, the workflow will ask follow-up questions.
- **Both**: Upload documents first, then fill in any gaps conversationally.

### Workflow

**Step 1: Welcome and orient the user**

Start every session by showing the user the full journey and asking how they want to proceed. This is mandatory — never skip it.

```
Welcome to the Discovery to Prototype Engine! Here's how the full journey works:

---

SENSE — Understand the landscape
  Stage 0   Set up product context (you are here)
  Stage 1.1 Analyze customer data (pNPS, support tickets, feedback)
  Stage 1.2 Research competitors and find market gaps
  Stage 1.3 Merge both into your Top 5 Opportunities (automatic)
  Stage 2   Score opportunities, pick one, and commit to a solution

SHAPE — Build the response
  Stage 3   Write the PRD (product requirements)
  Stage 4   Build or connect your component library
  Stage 5   Generate an interactive React prototype
  Stage 6   Create an experiment plan and usability test script

---

What would you like to do?

A) **Start from the beginning** — I'll guide you through every stage, step by step. All you need to do is follow my prompts after each stage.

B) **Jump to a specific stage** — Tell me which stage you want to start at (e.g. "Jump to Stage 4" or "I already have a PRD, go to Stage 5"). I'll ask for whatever inputs that stage needs.

**What you'll need for the full workflow:**
- Product context (a strategy doc, pitch deck, or just answers to a few questions)
- Customer data files (CSV exports of NPS, support tickets, or feedback)
- 3–5 competitor names

You don't need everything right now — I'll ask for what I need at each stage.

**Connected tools (auto-detected):**
If you have any of these connected in Cowork, I'll detect them automatically and offer to pull data directly — no file uploads needed:
- Intercom or BigQuery → replaces customer data CSV uploads at Stage 1.1
- Productboard → supplements customer insights (1.1) and competitive research (1.2)
- Figma → connects your design system directly at Stage 4 for high-fidelity component generation
- Lovable → lets you export and deploy the prototype directly at Stage 5
- Google Drive → saves all outputs to a shared folder so teammates can pick up where you left off

Which would you prefer — A or B?
```

Wait for the user's response before proceeding. If they choose B, ask which stage and what they already have. If they choose A, continue to Step 2 below.

**Step 2: Ask for context**

```
Let's start with your product context. You can:

📄 **Upload documents** — product strategy, pitch decks, one-pagers, market research, or anything that describes your product and market. I'll extract what I need.

✍️ **Or answer these questions directly:**

1. **Product name and description**: What does it do?
2. **Target audience**: Who are the primary users and what are their main pain points?
3. **Market and geography**: What industry, segment, and region do you serve?
4. **Key business goals**: What are your top 2-3 business objectives?
5. **Known competitors** (if any): Who do you compete with?

Or do both — upload what you have and I'll ask about anything that's missing.
```

**Step 3: Extract and structure**

When documents are provided, read them first and extract:
- Product name, description, and positioning
- Target audience and ideal customer profiles
- Market, geography, and segment definitions
- Business goals, KPIs, and North Stars
- Named competitors and competitive positioning
- Value propositions and differentiation claims

**Step 4: Confirm (Stage 0 checkpoint)**

Present the extracted context back to the user:

```
Here's the product context I've gathered:

**Product**: [name and description]
**Audience**: [target users and their pain points]
**Market**: [industry, geography, segment]
**Goals**: [top business objectives]
**Competitors**: [named competitors]

Does this look right? Anything to add or correct?
```

Wait for explicit confirmation before proceeding. This is Stage 0's checkpoint — corrections here prevent compounding errors downstream.

### Output

Once the user confirms the product context:

1. Create the working directory: `/home/claude/discovery-engine/`
2. Write the confirmed context to `/home/claude/discovery-engine/product-context.md` in this format:

```markdown
# Product Context

**Product**: [name and description]
**Target Audience**: [primary users and their pain points]
**Market**: [industry, geography, segment]
**Key Business Goals**: [top 2-3 objectives]
**Known Competitors**: [named competitors, if any]

## Additional Context
[Any other relevant details from uploaded documents or conversation]
```

3. Check whether Google Drive is connected. If it is, also save the product context to the shared Drive folder and note this in the confirmation. If not, save only to the local working directory.

4. After saving, show this handoff message to the user:

```
Product context saved. This will ground all downstream stages.
[If Google Drive is connected: Also saved to your shared Drive folder — teammates can access it there.]

---

Stage 0 complete! Here's what happens next:

**Stage 1 runs two tracks in parallel:**
- Stage 1.1 — Customer insights: I'll analyze your customer data to find pain points
- Stage 1.2 — Competitive landscape: I'll research your competitors to find market gaps

---

**Before we start, let me check what tools you have connected...**

At this point, check which connectors are available by calling `search_mcp_registry` with keywords like ["intercom", "hubspot", "bigquery", "google drive", "productboard"]. Then present the user with specific options based on what's available:

**For Stage 1.1 (Customer Data):**
Present these options directly — be specific, not generic:

> **How would you like to provide customer data?**
>
> 📄 **Upload CSV files** — export NPS scores, support tickets, or feedback from your tools and upload them here
>
> 📋 **Paste it directly** — copy-paste raw data, feedback excerpts, or summarised findings into the chat
>
> 🔗 **Connect a data source** — [check registry and list any available connectors with `suggest_connectors`]:
>   - Google Drive → pull CSVs from a shared folder
>   - HubSpot / Intercom → pull support tickets and feedback directly
>   - BigQuery → query your analytics warehouse
>   - Productboard → pull feature requests and customer insights
>
> 💬 **Just use what I told you** — skip data upload and work from the pain points I described in Stage 0
>
> Pick one, or combine them (e.g. upload CSVs and also connect Intercom).

**For Stage 1.2 (Competitors):**
> I already have your competitor names from Stage 0: [list them]. I'll research these using public sources. Want to add any others?

Only show connectors that are actually available in the registry. If a connector isn't connected yet, use `suggest_connectors` so the user can connect it with one click. If no relevant connectors are found, only show the upload/paste/describe options.
```

### After Stage 0

Once context is confirmed, determine what the user wants to run:
- **Full workflow**: Proceed to Stage 1 (ask for customer data files and competitor names)
- **Individual stage**: Route to the requested stage with context available
- **Resume from a stage**: Pick up where a previous run left off

---

## Stage 1.3: Opportunity Framing (Internal Merge Step)

After Stages 1.1 and 1.2 complete (in parallel or sequentially), the orchestrator runs this merge step internally. This is NOT delegated to a separate skill.

### Inputs

Read the output files from Stages 1.1 and 1.2:
- `view /home/claude/discovery-engine/stage-1-1-customer-insights.md` — Pain points + need patterns with severity scores, user segments, and business impact
- `view /home/claude/discovery-engine/stage-1-2-competitive-landscape.md` — Competitive gap summary with signal strengths and maturity labels

Use **only the file contents** as input. Do not reference earlier conversation history from the Stage 1.1 or 1.2 exploration — the files are the canonical, confirmed outputs.

If only one file is available, proceed but flag lower confidence on opportunities that lack corroboration.

### Step 1: Cross-Reference

Map each customer pain point from 1.1 against the competitive gap summary from 1.2. Look for:

- **Direct overlaps**: A customer pain point that also appears as a competitor weakness or market whitespace
- **Reinforcing signals**: A customer pain point where competitors are investing (emerging trend) — suggests the market is moving and urgency is high
- **Contradictions**: A customer pain point where competitors already excel — suggests catch-up rather than differentiation

Also scan the competitive gaps for items that don't appear in customer data — these are potential market-driven opportunities.

### Step 2: Classify by Evidence Source

Tag each candidate opportunity with one of three labels:

| Label | Meaning | Typical Priority |
|-------|---------|-----------------|
| **Validated** | Appears in both customer data AND competitive analysis | Highest — pain is real and market confirms the gap |
| **Customer-driven** | Appears in customer data only (1.1) | High if severity ≥7 — real pain, unclear competitive angle |
| **Market-driven** | Appears in competitive analysis only (1.2) | Strategic bet — no customer signal yet, but competitive whitespace exists |

**Composition guideline:** The Top 5 should lean toward Validated and Customer-driven opportunities. Include a maximum of 1-2 Market-driven opportunities, and only if signal strength is Strong.

### Step 3: Rank and Output

Produce a lean summary table followed by detailed rationale per opportunity. See `references/opportunity-merge-template.md` for the exact output format.

**Top 5 Opportunities Table:**

```
| Rank | Opportunity | Evidence | Business Impact | Rationale |
|------|------------|----------|-----------------|-----------|
| 1 | [Name] | Validated | [H/M/L] | [One-liner: why this is #1] |
| 2 | [Name] | Validated | [H/M/L] | [One-liner] |
| 3 | [Name] | Customer-driven | [H/M/L] | [One-liner] |
| 4 | [Name] | Customer-driven | [H/M/L] | [One-liner] |
| 5 | [Name] | Market-driven | [H/M/L] | [One-liner] |
```

**Detailed Rationale:** Below the table, provide a 2-4 sentence paragraph for each opportunity that traces back to specific evidence from 1.1 and/or 1.2, so the PM can verify the reasoning.

### Step 4: Checkpoint

After presenting the Top 5:

1. Ask: "Do these opportunities look right? Want to reorder, swap any out, or adjust the framing?"
2. Flag any opportunities where confidence is lower (single-source evidence)
3. Note any strong signals from 1.1 or 1.2 that didn't make the Top 5, as "honourable mentions"
4. Confirm the user is satisfied before proceeding to Stage 2

### Step 5: Write Output File

Once the user confirms the Top 5, write the final ranked opportunities to `/home/claude/discovery-engine/stage-1-3-top-5-opportunities.md`. Include the summary table and the detailed rationale for each opportunity. This file is the input for Stage 2.

After writing the file, also save a copy to the user's workspace folder and present it as a downloadable artifact using `present_files`. This lets the user share the output with their team, paste it into a deck, or re-upload it later to resume from this stage:

1. Copy the file to the workspace/outputs folder (e.g. `/mnt/user-data/outputs/stage-1-3-top-5-opportunities.md`)
2. Use `present_files` to show the file to the user

Do this at every stage transition where an output file is written — not just Stage 1.3. The user should always receive a downloadable artifact after each checkpoint confirmation.

### Edge Cases

- **Only Stage 1.1 available**: Produce Top 5 from customer data alone. All tagged as "Customer-driven." Note that competitive validation is missing.
- **Only Stage 1.2 available**: Produce Top 5 from competitive gaps alone. All tagged as "Market-driven." Note that customer validation is missing.
- **Fewer than 5 strong opportunities**: Output fewer rather than padding with weak ones.
- **More than 5 strong overlaps**: Present the Top 5 and list the remainder as "strong runners-up."

---

## Stage Overview

| Stage | Name | Phase | Output | Checkpoint |
|-------|------|-------|--------|------------|
| **0** | **Workflow Orchestration** | — | **Confirmed product context** | **Confirm context is correct** |
| 1.1 | Customer Insights | Sense | Pain points + need patterns with severity scores | Review & correct |
| 1.2 | Competitive Landscape | Sense | Competitor comparison table + gap summary with signal strengths | Review & correct |
| 1.3 | Opportunity Framing (internal) | Sense | Ranked Top 5 Opportunities with evidence sourcing | Review & approve opportunities |
| 2a | Opportunity Scoring | Sense | Scored matrix with rankings, reasoning, confidence levels | **User selects opportunity** |
| 2b | Solution Exploration | Sense | 3-5 solution concepts with agentic/non-agentic flags | **User commits to solution** |
| 3.1 | PRD Foundation (non-agentic) | Shape | Concise PRD | Approve scope |
| 3.2+3.3 | Agent PRD (agentic) | Shape | Agent behavior script → Concise PRD with agent behavior | Review agent design, then approve scope |
| 4 | Component Library | Shape | Reusable React components | Review fidelity |
| 5 | Prototype Generator | Shape | Interactive React prototype | Iterate & approve |
| 6 | Experiment Plan | Shape | Test plan + usability script | Finalize |

**Note:** Stages 2a and 2b are two phases within a single skill (`discovery-solution-prioritization`), not separate skills. The checkpoint between them is a hard pause — the user must select an opportunity before solution exploration begins.

## Stage-Specific Inputs

| Input | Needed for | Location | Format |
|-------|-----------|----------|--------|
| Product context docs (optional) | Stage 0 → all stages | Upload | PDF, DOCX, PPTX, or text |
| Customer data | Stage 1.1 | Upload or Google Drive `/data/` subfolder | CSVs (pNPS, CES, support, feedback, usage) |
| Competitors (if not in context) | Stage 1.2 | Provided by user or identified via research | 2-4 competitor names |

## Running the Workflow

### Full Workflow (recommended)

Say: "Run the full discovery to prototype workflow" and provide:
1. Product context — upload strategy docs/decks OR answer context questions (or both)
2. Customer data files (or Google Drive folder link)

The workflow will:
1. **Stage 0**: Ingest product context, confirm with user
2. **Stage 1.1 + 1.2**: Run customer insights and competitive landscape (in parallel via subagents in Cowork, or sequentially in Claude.ai)
3. **Stage 1.3**: Merge both outputs into ranked Top 5 Opportunities (orchestrator handles this internally)
4. **Stage 2a**: Score opportunities across four dimensions, rank them — user selects which opportunity to explore
5. **Stage 2b**: Brainstorm 3-5 solution concepts for the selected opportunity, each flagged as agentic or non-agentic — user commits to one solution
6. **Stage 3**: Create PRD — orchestrator reads the agentic flag from Stage 2's output and routes to non-agentic (3.1) or agentic (Agent PRD) path
7. **Stage 4**: Build or connect component library (auto-detects existing libraries, or asks for design system input)
8. **Stage 5**: Generate interactive prototype from PRD + components
9. **Stage 6**: Create experiment plan and usability test script

Each stage pauses at its checkpoint for your input before proceeding.

### Branching at Stage 3: Non-Agentic vs. Agentic

The orchestrator does NOT decide the branch itself. After Stage 2 completes, read `/home/claude/discovery-engine/stage-2-selected-opportunity.md` and check the agentic/non-agentic flag. Route accordingly:

- **Flag = non-agentic** → delegate to `discovery-prd-foundation` (Stage 3.1) — pass it `product-context.md` + `stage-2-selected-opportunity.md`
- **Flag = agentic** → delegate to `discovery-agent-prd` (Stage 3.2+3.3) — pass it `product-context.md` + `stage-2-selected-opportunity.md`

Both paths output a concise PRD that feeds into Stage 4 (Component Library).

### Individual Stages

Each stage can run independently:

| To run... | Say... |
|-----------|--------|
| Stage 0 only | "Set up product context" or "Ingest context for the engine" |
| Stage 1.1 only | "Analyze this customer data" |
| Stage 1.2 only | "Research competitors" or "Competitive analysis" |
| Stage 1.3 only | "Frame opportunities" (needs 1.1 and/or 1.2 output) |
| Stage 2 only | "Prioritize these opportunities" or "Score these opportunities" |
| Stage 3.1 only | "Create a PRD for [opportunity]" |
| Agent PRD only | "Design agent behavior for [solution]" or "Create agentic PRD" |
| Stage 4 only | "Build component library" or "Connect my design system" |
| Stage 5 only | "Generate prototype for [PRD]" |
| Stage 6 only | "Create experiment plan for [prototype]" |

### Resume from Stage

If workflow was interrupted, resume from any stage:
- "Continue from Stage 2" (provide previous outputs)
- "Pick up at prototype generation"

## Workflow Behavior

### Checkpoints

At each checkpoint, the workflow will:
1. Present the stage output
2. Ask for your review
3. Wait for explicit approval or corrections
4. Only proceed when you confirm

**Checkpoint phrases**:
- "Looks good, continue" → Proceed to next stage
- "Let me review" → Pause for detailed review
- "Change X" → Make adjustments before proceeding
- "Stop here" → Save progress, end workflow

### Passing Context

Stage outputs are passed via structured files in `/home/claude/discovery-engine/`. At each stage transition, read the relevant output file(s) and use their contents as the canonical input — not conversation history.

- **Stage 0** → writes `product-context.md` → read by all downstream stages
- **Stage 1.1** → writes `stage-1-1-customer-insights.md` → read by orchestrator for 1.3 merge
- **Stage 1.2** → writes `stage-1-2-competitive-landscape.md` → read by orchestrator for 1.3 merge
- **Stage 1.3** → writes `stage-1-3-top-5-opportunities.md` → read by Stage 2
- **Stage 2** → writes `stage-2-selected-opportunity.md` → read by orchestrator for branch decision → passed to Stage 3
- **Stage 3** → writes PRD to `/mnt/user-data/outputs/` → read by Stage 4
- **Stage 4** → writes component library to `/home/claude/component-library/` → read by Stage 5
- **Stage 5** → writes prototype to `/mnt/user-data/outputs/` → read by Stage 6
- **Stage 6** → writes test plan to `/mnt/user-data/outputs/` → delivered to user

**Why files over conversation history:** In Cowork, subagent context windows are destroyed when they complete — files are the only way to pass state. In Claude.ai chat, conversation history persists but grows noisy with exploration. Reading a file puts the confirmed output at the end of context where attention is strongest, avoiding "lost in the middle" degradation.

### Presenting Stage Outputs as Artifacts

After every stage checkpoint — once the user confirms the output — save the stage output as a downloadable file and present it to the user. This is mandatory for all stages.

**Why:** Users need to share outputs with teammates, paste them into decks, or re-upload them in future sessions to resume the workflow. If outputs only exist in the working directory, they're invisible and lost when the session ends.

**How:**
1. Write the output file to the working directory (as already specified)
2. Also copy the file to the user's workspace/outputs folder
3. Call `present_files` to show the file in the chat as a downloadable card

**Files to present at each stage:**

| Stage | File to present | Format |
|-------|----------------|--------|
| 0 | `product-context.md` | Markdown |
| 1.1 | `stage-1-1-customer-insights.md` | Markdown |
| 1.2 | `stage-1-2-competitive-landscape.md` | Markdown |
| 1.3 | `stage-1-3-top-5-opportunities.md` | Markdown |
| 2 | `stage-2-selected-opportunity.md` | Markdown |
| 3 | PRD document | Markdown |
| 4 | Component library (zipped folder) | .zip |
| 5 | Prototype | .html or .jsx |
| 6 | Experiment plan + test script | Markdown |

The presentation message should be brief: "Here's your [Stage X] output — you can download it, share it with your team, or re-upload it later to resume from this point."

### Persistent Artifacts

| Artifact | Saved To | Reusable |
|----------|----------|----------|
| Stage output files (Stages 0–2) | `/home/claude/discovery-engine/` | Per run |
| Component Library | `/home/claude/component-library/` | ✅ Yes |
| Prototype | `/mnt/user-data/outputs/` | Per project |
| PRD | `/mnt/user-data/outputs/` | Per project |
| Test Script | `/mnt/user-data/outputs/` | Per project |

## Tips for Best Results

### Product Context (Stage 0)
- Uploading a strategy doc or pitch deck is the fastest way to provide context — the workflow will extract what it needs and ask about gaps
- Be specific about your target audience — "Nordic SMBs in construction with 10-50 employees" is better than "small businesses"
- Include your top 2-3 business goals — this directly influences opportunity scoring in Stage 2
- Name your known competitors — even 2-3 names gives Stage 1.2 a strong starting point

### Data Preparation
- Ensure CSVs have clear column headers
- Include verbatim feedback, not just scores
- More data sources = stronger cross-referencing

### Component Library (Stage 4)
- If your team has a component library repo (with manifest.json, tokens.json, prompt-rules.md, and React components), clone it locally and run the workflow in Claude Code — Stage 4 will auto-detect it and skip generation entirely. This is the highest-fidelity path.
- If working in Cowork, upload your design system files (manifest.json, tokens.json, prompt-rules.md) to your Claude Project — Stage 4 will find them in the project context.
- If you have Figma connected, Stage 4 can pull your design system directly.
- No design system at all? Stage 4 will ask for product screenshots or offer to build from scratch.

### At Checkpoints
- Take time to review outputs carefully
- Corrections early save time later
- Don't hesitate to ask for changes

## Reference: Individual Skill Documentation

For detailed guidance on each stage, refer to:
- `discovery-customer-insights` — Stage 1.1 (Customer Insights)
- `discovery-competitive-landscape` — Stage 1.2 (Competitive Landscape)
- Stage 1.3 (Opportunity Framing) — handled internally by this orchestrator
- `discovery-solution-prioritization` — Stage 2 (Solution Prioritization)
- `discovery-prd-foundation` — Stage 3.1 (PRD Foundation, non-agentic)
- `discovery-agent-prd` — Stage 3.2+3.3 (Agent PRD, agentic)
- `discovery-component-library` — Stage 4 (Component Library)
- `discovery-prototype-generator` — Stage 5 (Prototype)
- `discovery-experiment-plan` — Stage 6 (Experiment Plan)
